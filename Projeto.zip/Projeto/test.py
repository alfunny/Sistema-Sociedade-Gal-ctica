import getpass
import oracledb

# user = 'a10727952'
# host = 'orclgrad1.icmc.usp.br'
# pw = 'bsi2022'  #getpass.getpass(f'Enter password for {un}@{cs}: ')

# Conecta ao banco de dados Oracle
connection = oracledb.connect(user="a10727952", password='bsi2022',
                              host="orclgrad1.icmc.usp.br", port=1521, service_name="pdb_elaine.icmc.usp.br")
# print("Database version: ", connection.version)

# Cursor
cursor = connection.cursor()

cursor.execute('SELECT * FROM LIDER')

# Imprime os resultados
for row in cursor:
    print(row)

connection.close()

