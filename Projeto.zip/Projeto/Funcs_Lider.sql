-- LIDER

SELECT * FROM USER_ERRORS;
-- ========================= PACKAGE LIDER =========================
CREATE OR REPLACE PACKAGE pacote_func_lider AS
   
	PROCEDURE alterar_nome_faccao(p_faccao faccao.nome%TYPE, p_novo_nome faccao.nome%TYPE);
--	PROCEDURE indicar_lider(lider_atual lider.cpi%TYPE, novo_lider lider.cpi%TYPE);
	PROCEDURE inserir_view_ger_comunidades(p_faccao faccao.nome%TYPE);
	PROCEDURE remover_faccao(p_faccao faccao.nome%TYPE, p_nacao nacao.nome%TYPE);

END pacote_func_lider;


CREATE OR REPLACE PACKAGE BODY pacote_func_lider AS

	-------------------- ALTERAR NOME DA FACCAO --------------------
	PROCEDURE alterar_nome_faccao (
	    p_faccao IN faccao.nome%TYPE,
	    p_novo_nome IN faccao.nome%TYPE
	) AS
	
	    e_faccao_nao_encontrada EXCEPTION;
	    pragma exception_init(e_faccao_nao_encontrada, -20001);
	
	BEGIN  
	   
		-- atualizar o nome da faccao na tabela faccao
	    UPDATE faccao SET NOME = p_novo_nome WHERE NOME = p_faccao;
		
	   	-- verificar atualizacao
	    IF SQL%ROWCOUNT = 0 THEN
	        raise e_faccao_nao_encontrada;
	    END IF;
	   
		-- atualizar o nome da faccao na tabela nacao_faccao
	    UPDATE nacao_faccao SET FACCAO = p_novo_nome WHERE FACCAO = p_faccao;
	
	   	-- atualizar o nome da faccao na tabela participa
	   	UPDATE participa SET FACCAO = p_novo_nome WHERE FACCAO = p_faccao;
	   
	    COMMIT;
	  
	    dbms_output.put_line('Nome da facção ' || p_faccao || ' alterado para ' || p_novo_nome);
	
	EXCEPTION
	    WHEN e_faccao_nao_encontrada THEN
	        raise_application_error(-20001, 'Erro: Facção não encontrada.');
	    	ROLLBACK;
		WHEN OTHERS THEN
		    raise_application_error(-20000, 'Erro ao alterar facção: ' || SQLERRM);
		    ROLLBACK;
		    raise;
	
	END alterar_nome_faccao;

	-------------------- INDICAR UM NOVO LIDER PARA A FACCAO --------------------
--	PROCEDURE indicar_lider (
--		p_lider_atual IN lider.CPI%TYPE,
--	    p_novo_lider IN lider.CPI%TYPE
--	    --p_faccao OUT faccao.NOME%TYPE
--	    ) AS 
--	 	e_lider_nao_encontrado EXCEPTION;
--	    pragma exception_init(e_lider_nao_encontrado, -20002);
--	
--	BEGIN
--		   -- atualizar o nome da faccao na tabela faccao
--	    UPDATE faccao SET lider = p_novo_lider WHERE lider = p_lider_atual;
--		
--	   	-- verificar atualizacao
--	    IF SQL%ROWCOUNT = 0 THEN
--	        raise e_lider_nao_encontrado;
--	    END IF;
--	   
--	    COMMIT;
--	   
--	   	SELECT faccao.NOME INTO p_faccao FROM FACCAO WHERE LIDER = p_novo_lider;
--	  
--	    dbms_output.put_line('Lider ' || p_novo_lider || ' é o novo responsável pela facção ' || ', indicado pelo antigo líder ' || p_lider_atual);
--	   --p_faccao || 
--	EXCEPTION
--		WHEN e_lider_nao_encontrado THEN
--			raise_application_error(-20002, 'O CPI informado não corresponde a nenhum líder atual.');
--			ROLLBACK;
--		WHEN OTHERS THEN
--		    raise_application_error(-20000, 'Erro ao alterar facção: ' || SQLERRM);
--		    ROLLBACK;	   
--	END indicar_lider;	

	-------------------- CREDENCIAR COMUNIDADES NOVAS --------------------
	-- INSERCAO PELA VIEW
	PROCEDURE inserir_view_ger_comunidades(p_faccao IN faccao.nome%TYPE) AS
	BEGIN
	    FOR r_comunidade IN (
	        SELECT nf.faccao, nf.nacao, d.planeta, c.especie, c.nome AS comunidade
	        FROM
	            nacao_faccao nf
	            JOIN dominancia d ON nf.nacao = d.nacao AND (d.data_fim IS NULL OR d.data_fim > SYSDATE)
	            JOIN habitacao h ON d.planeta = h.planeta
	            JOIN comunidade c ON h.especie = c.especie AND h.comunidade = c.nome
	            LEFT JOIN participa p ON nf.faccao = p.faccao AND c.especie = p.especie AND c.nome = p.comunidade
	        WHERE nf.faccao = p_faccao AND p.faccao IS NULL
	    ) LOOP
	        	INSERT INTO view_gerenciamento_comunidades (faccao, nacao, planeta, especie, comunidade)
	        		VALUES (r_comunidade.faccao, r_comunidade.nacao, r_comunidade.planeta, r_comunidade.especie, r_comunidade.comunidade);
	    	END LOOP;
	        
	        COMMIT;
	        
	        dbms_output.put_line('Comunidades inseridas com sucesso!');
	   
	EXCEPTION
	    WHEN OTHERS THEN
	        ROLLBACK;
	        raise_application_error(-20000, 'Erro: ' || SQLERRM);
	END inserir_view_ger_comunidades;

	-------------------- REMOVER FACCAO --------------------
	PROCEDURE remover_faccao (
	    p_faccao IN faccao.nome%TYPE,
	    p_nacao IN nacao.nome%TYPE
	) AS
	
	    e_faccao_nao_encontrada EXCEPTION;
	    pragma exception_init(e_faccao_nao_encontrada, -20001);
	
	BEGIN
	        
	    DELETE FROM nacao_faccao WHERE nacao = p_nacao AND faccao = p_faccao;
	    
	    -- verificar remocao
	    IF SQL%ROWCOUNT = 0 THEN
	        raise e_faccao_nao_encontrada;
	    END IF;
	
	    COMMIT;
	  
	    dbms_output.put_line('Facção ' || p_faccao || ' removida da nação ' || p_nacao);
	
	EXCEPTION
	    WHEN e_faccao_nao_encontrada THEN
	        ROLLBACK;
	       	raise_application_error(-20001, 'Erro: Facção não encontrada para a nação informada.');
	    WHEN OTHERS THEN
	        ROLLBACK;
	       	raise_application_error(-20000, 'Erro ao remover facção: ' || SQLERRM);
	        raise;
	
	END remover_faccao;

END pacote_func_lider;


-- ========================= VIEW GERENCIAMENTO COMUNIDADES =========================
-- criacao de uma view para que possam ser gerados os relatorios
CREATE OR REPLACE VIEW view_gerenciamento_comunidades AS
SELECT 
    nf.faccao, nf.nacao, d.planeta, s.nome AS sistema, c.especie, c.nome AS comunidade, c.qtd_habitantes,
    CASE
        WHEN p.faccao IS NOT NULL THEN 'Credenciada'
        ELSE 'Não Credenciada'
    END AS status_credenciamento
FROM
    nacao_faccao nf
    JOIN dominancia d ON nf.nacao = d.nacao AND (d.data_fim IS NULL OR d.data_fim > SYSDATE)
    JOIN habitacao h ON d.planeta = h.planeta
    JOIN comunidade c ON h.especie = c.especie AND h.comunidade = c.nome
    LEFT JOIN participa p ON nf.faccao = p.faccao AND c.especie = p.especie AND c.nome = p.comunidade
    LEFT JOIN orbita_planeta op ON d.planeta = op.planeta
    LEFT JOIN sistema s ON op.estrela = s.estrela;

   
-- ========================= TRIGGER INSTEAD-OF CREDENCIAMENTO DE COMUNIDADES =========================
CREATE OR REPLACE TRIGGER trigger_view_gerenciamento_comunidades
INSTEAD OF INSERT ON view_gerenciamento_comunidades
FOR EACH ROW
BEGIN
    INSERT INTO participa(faccao, especie, comunidade) VALUES(:NEW.faccao, :NEW.especie, :NEW.comunidade);
END;
--DROP TRIGGER trigger_view_gerenciamento_comunidades;
-- ========================= TRIGGER INSERT/UPDATE/DELETE FACCAO =========================
-- este trigger vincula a faccao à nacao do lider: nacao_faccao, o resto é automatico atravez da view de gerenciamento
CREATE OR REPLACE TRIGGER trigger_faccao
  	AFTER INSERT OR UPDATE OR DELETE ON faccao
  	FOR EACH ROW
  	
DECLARE
  	v_count NUMBER;
  	v_nacao nacao.nome%TYPE;
  
BEGIN

	SELECT l.nacao INTO v_nacao FROM lider l WHERE l.CPI = :NEW.lider;

	IF v_nacao IS NULL THEN
		raise no_data_found;
	END IF;
  
	IF INSERTING THEN
		SELECT COUNT(*) INTO v_count FROM nacao_faccao WHERE nacao = v_nacao AND faccao = :NEW.nome;
	  	IF v_count = 0 THEN
	  		INSERT INTO nacao_faccao(NACAO, FACCAO) VALUES(v_nacao, :NEW.nome);
		  	dbms_output.put_line('Nova facção inserida e vinculada à nação do líder!');
	   	END IF;
   	ELSIF UPDATING THEN
   	        SELECT COUNT(*) INTO v_count FROM nacao_faccao WHERE faccao = :OLD.nome;
        IF v_count > 0 THEN
            UPDATE nacao_faccao SET nacao = v_nacao WHERE faccao = :NEW.nome;
            dbms_output.put_line('Informações atualizadas!');
        ELSE
            INSERT INTO nacao_faccao (NACAO, FACCAO) VALUES (v_nacao, :NEW.nome);
            dbms_output.put_line('Nova facção inserida e vinculada à nação do líder!');
        END IF;
	ELSIF DELETING THEN
		SELECT COUNT(*) INTO v_count FROM nacao_faccao WHERE nacao = v_nacao AND faccao = :OLD.nome;
		IF v_count > 0 THEN
  			DELETE FROM nacao_faccao WHERE faccao = :OLD.nome;
  		END IF;
	END IF;
   
EXCEPTION
	WHEN no_data_found THEN
		raise_application_error(-20001, 'O líder informado não está cadastrado!');
		ROLLBACK;
END;

-- ========================= TRIGGER DELETE NACAO_FACCAO =========================
CREATE OR REPLACE TRIGGER trigger_nacao_faccao
    AFTER DELETE ON nacao_faccao
    FOR EACH ROW

DECLARE
    v_count NUMBER;
    v_especie comunidade.especie%TYPE;
    v_comunidade comunidade.nome%TYPE;

BEGIN
	-- verificando se tem registro em Participa
    SELECT COUNT(*) INTO v_count FROM PARTICIPA WHERE faccao = :OLD.faccao;

    IF v_count > 0 THEN
        -- obtendo especie e comunidade da tabela PARTICIPA
        SELECT p.especie, p.comunidade INTO v_especie, v_comunidade
        FROM PARTICIPA p WHERE faccao = :OLD.faccao
        AND ROWNUM = 1; -- adicionado ROWNUM = 1 para evitar mais de um resultado

        -- deletando da tabela PARTICIPA
        DELETE FROM PARTICIPA WHERE faccao = :OLD.faccao
        AND especie = v_especie AND comunidade = v_comunidade;
    ELSE
        raise_application_error(-20001, 'Facção não credenciada!');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        raise_application_error(-20001, 'Facção não credenciada!');
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Erro: ' || SQLERRM);
END;



------------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM user_errors WHERE name='trigger_view_gerenciamento_comunidades';

---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------


-- RELATÓRIOS

-- 1)

-- a. Informações sobre comunidades da própria facção: um líder de facção está
-- interessado em recuperar informações sobre as comunidades participantes,
-- facilitando a tomada de decisões de expansão da própria facção.

-- i. Comunidades podem ser agrupadas por nação, espécie, planeta, e/ou sistema.

-- CONSULTA
-- Visualizacao de informacoes
    
-- procedure de impressao da view completa
CREATE OR REPLACE PROCEDURE relatorio_comunidades(
    p_faccao IN faccao.nome%TYPE
) AS
    v_count NUMBER;
    
    e_faccao_nao_pertencente EXCEPTION;
    pragma exception_init(e_faccao_nao_pertencente, -20002);

BEGIN
    SELECT COUNT(*) INTO v_count FROM view_gerenciamento_comunidades WHERE faccao = p_faccao;

    IF v_count > 0 THEN
    
    	dbms_output.put_line('GERENCIAMENTO DE COMUNIDADES PERTENCENTES À FACÇÃO ' || p_faccao);
        -- Linha de separação
        dbms_output.put_line(RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 21, '-'));
        
        -- Cabeçalho
        dbms_output.put_line(RPAD('|', 2) || RPAD('Nação', 18) ||
                             RPAD('|', 2) || RPAD('Planeta', 18) ||
                             RPAD('|', 2) || RPAD('Sistema', 18) ||
                             RPAD('|', 2) || RPAD('Espécie', 18) ||
                             RPAD('|', 2) || RPAD('Comunidade', 18) ||
                             RPAD('|', 2) || RPAD('Qtd_Habitantes', 18) ||
                             RPAD('|', 2) || RPAD('Status', 18) || '|');
        
        -- Linha de separação
        dbms_output.put_line(RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 21, '-'));
        
        -- Dados
        FOR r IN (SELECT * FROM view_gerenciamento_comunidades WHERE faccao = p_faccao)
        LOOP
            dbms_output.put_line(
                RPAD('|', 2) || RPAD(NVL(r.nacao, ' '), 18) || 
                RPAD('|', 2) || RPAD(NVL(r.planeta, ' '), 18) || 
                RPAD('|', 2) || RPAD(NVL(r.sistema, ' '), 18) ||
                RPAD('|', 2) || RPAD(NVL(r.especie, ' '), 18) || 
                RPAD('|', 2) || RPAD(NVL(r.comunidade, ' '), 18) ||
                RPAD('|', 2) || RPAD(NVL(TO_CHAR(r.qtd_habitantes), '0'), 18) ||
                RPAD('|', 2) || RPAD(NVL(r.status_credenciamento, ' '), 18) || '|'
            );
        END LOOP;
        
        -- Linha de separação final
        dbms_output.put_line(RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || RPAD('-', 21, '-'));
    ELSE
        raise e_faccao_nao_pertencente;
    END IF;

EXCEPTION
    WHEN e_faccao_nao_pertencente THEN
        raise_application_error(-20002, 'A facção não corresponde ao líder informado.');
    WHEN OTHERS THEN
        raise_application_error(-20000, 'Erro ao visualizar informações' || SQLERRM);
END;


-- programa principal
DECLARE
    v_faccao faccao.nome%TYPE;
    v_agrupamento char(1);
BEGIN
    v_faccao := 'CENTRAL_DO_MEDO';
   	v_agrupamento := 'n';				-- agrupamento: nação, espécie, planeta, e/ou sistema
    relatorio_comunidades(v_faccao);
END;


-- verificando as insercoes na tabela participa
SELECT * FROM PARTICIPA;


DECLARE
  v_faccao VARCHAR2(15);
  v_agrupamento VARCHAR2(20);
BEGIN
  SELECT
    v_faccao,
    v_agrupamento,
    COUNT(*) AS qtd_comunidades,
    -- ... (detalhes adicionais por agrupamento)
  FROM ...
  GROUP BY v_faccao, v_agrupamento;
END;


--INSERT INTO ORBITA_PLANETA(PLANETA, ESTRELA, DIST_MIN, DIST_MAX, PERIODO) VALUES('Est a.', '4    Vul', 2351, 2548, 3);
--
--INSERT INTO SISTEMA(ESTRELA, NOME) values('4    Vul', 'SOLAR');



CREATE OR REPLACE PROCEDURE INSERT_DOMINANCIA (
    p_planeta dominancia.PLANETA%TYPE,
    p_nacao dominancia.NACAO%TYPE,
    p_data_ini dominancia.DATA_INI%TYPE,
    p_data_fim dominancia.DATA_FIM%TYPE
) AS
    v_count NUMBER;

    -- Exceções personalizadas
    ex_planeta_nao_encontrado EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_planeta_nao_encontrado, -20001);
  
    ex_planeta_ja_dominado EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_planeta_ja_dominado, -20002);
   
    ex_nacao_nao_encontrada EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_nacao_nao_encontrada, -20003);
BEGIN
    -- Verificar se o planeta existe
    SELECT COUNT(*)
    INTO v_count
    FROM PLANETA
    WHERE ID_ASTRO = p_planeta;

    IF v_count = 0 THEN
        RAISE ex_planeta_nao_encontrado;
    END IF;
   
       -- Verificar se a nação existe
    SELECT COUNT(*)
    INTO v_count
    FROM NACAO
    WHERE NOME = p_nacao;

    IF v_count = 0 THEN
        RAISE ex_nacao_nao_encontrada;
    END IF;

    -- Verificar se o planeta não está sendo dominado por ninguém
    SELECT COUNT(*)
    INTO v_count
    FROM DOMINANCIA
    WHERE PLANETA = p_planeta AND (DATA_FIM IS NULL OR DATA_FIM >= SYSDATE);

    IF v_count > 0 THEN
        RAISE ex_planeta_ja_dominado;
    END IF;

    -- Inserir a nova dominância
    INSERT INTO DOMINANCIA (PLANETA, NACAO, DATA_INI, DATA_FIM)
    VALUES (p_planeta, p_nacao, p_data_ini, p_data_fim);
    DBMS_OUTPUT.PUT_LINE('Dominância inserida com sucesso.');

EXCEPTION
    WHEN ex_planeta_nao_encontrado THEN
        RAISE_APPLICATION_ERROR(-20001, 'Erro: O planeta especificado não existe.');
    WHEN ex_planeta_ja_dominado THEN
        RAISE_APPLICATION_ERROR(-20002, 'Erro: O planeta já está sendo dominado.');
    WHEN ex_nacao_nao_encontrada THEN
        RAISE_APPLICATION_ERROR(-20002, 'Erro: A nação especificada não existe.');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20004, 'Erro desconhecido: ' || SQLERRM);
END;







