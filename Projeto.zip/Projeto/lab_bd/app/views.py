from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST
from django.http import HttpResponse
from django.db import connection
from app.utils import *
from app.models import *
from django.contrib import messages


@require_POST
def verificar_login(request):
    cpi = request.POST.get('cpi')
    password = request.POST.get('password')
    
    try:
        user = Users.objects.get(id_lider=cpi)
        
        if user.password == password:
            lider = user.id_lider
            
            if lider.cargo == 'COMANDANTE':
                return render(request, 'comandante.html')
            elif lider.cargo == 'CIENTISTA':
                return render(request, 'cientista.html')
            elif lider.cargo == 'OFICIAL':
                return render(request, 'oficial.html')
            else:
                print('pagina nao encontrada')
                mensagem = f"Erro ao fazer login: Página não encontrada."
                return render(request, 'pagina_erro.html', {'mensagem': mensagem})
        else:
            print('senha incorreta')
            mensagem = f"Erro ao fazer login: Senha incorreta."
            return render(request, 'pagina_erro.html', {'mensagem': mensagem})
    
    except Users.DoesNotExist:
        print('usuario nao existe')
        mensagem = f"Erro ao fazer login: Usuário '{cpi}' não encontrado."
        return render(request, 'pagina_erro.html', {'mensagem': mensagem})


@require_POST
def view_atualizar_nome_faccao(request):
    faccao_atual = request.POST.get('faccao_atual')
    novo_nome = request.POST.get('novo_nome')
    
    try:
        alterar_nome_faccao(faccao_atual, novo_nome)
        mensagem = f"Sucesso na alteração: Nome da facção '{faccao_atual}' alterado para '{novo_nome}'"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    except Exception as e:
        # Tratamento de erro: redireciona para uma página de erro
        mensagem_e = f"Erro na alteração: Nome da facção '{faccao_atual}' não pode ser alterado para '{novo_nome}'"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})

@require_POST
def view_cadastro_comun_cred(request):
    faccao = request.POST.get('faccao')
    
    try:
        cadastrar_comunidades_cred(faccao)
        mensagem = f"Sucesso no credenciamento de comunidades para a Facção '{faccao}'"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    except Exception as e:
        # Tratamento de erro: redireciona para uma página de erro
        mensagem = f"Erro no credenciamento de comunidades para a Facção '{faccao}'"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem})


@require_POST
def view_remover_faccao_de_nacao(request):
    faccao = request.POST.get('faccao')
    nacao = request.POST.get('nacao')
    
    try:
        remover_faccao_de_nacao(faccao, nacao)
        mensagem = f"Sucesso! Facção '{faccao}' não está mais vinculada à nação '{nacao}'"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    except Exception as e:
        # Tratamento de erro: redireciona para uma página de erro
        mensagem = f"Erro! Facção '{faccao}' não foi desvinculada da nação '{nacao}'"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem})




# from django.shortcuts import render
# from .models import Faccao

# def faccao_list(request):pacote_func_lider.remover_faccao(v_faccao, v_nacao)
#     faccoes = Faccao.objects.all()
#     print(faccoes)  # Adicione esta linha para imprimir os dados no console
#     return render(request, 'faccao_list.html', {'faccoes': faccoes})


def gerar_relatorio_view(request):
    if request.method == 'POST':
        nome_faccao = request.POST.get('faccao')
        resultado_procedimento = []

        try:
            with connection.cursor() as cursor:
                # Habilitar DBMS_OUTPUT
                cursor.execute("BEGIN DBMS_OUTPUT.ENABLE(NULL); END;")
                
                # Chamar o procedimento PL/SQL
                cursor.callproc('relatorio_comunidades', [nome_faccao])

                # Capturar a saída de DBMS_OUTPUT
                output_buffer = cursor.var(str).array(1000)
                cursor.callproc('DBMS_OUTPUT.GET_LINES', [output_buffer, cursor.var(int)])

                for line in output_buffer:
                    if line:
                        resultado_procedimento.append(line)

                # Desabilitar DBMS_OUTPUT
                cursor.execute("BEGIN DBMS_OUTPUT.DISABLE(); END;")

                # Renderizar o template com os resultados
                return render(request, 'resultado_relatorio.html', {'resultado_procedimento': resultado_procedimento})

        except Exception as e:
            return HttpResponse(f'Erro ao executar procedimento PL/SQL: {str(e)}')

    # Renderizar o template da página onde está o formulário
    return render(request, 'lider.html')