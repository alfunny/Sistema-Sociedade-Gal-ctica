from django.shortcuts import render
from django.views.decorators.http import require_POST
from .models import Users, Faccao
from django.db import connection
from datetime import datetime
from app.utils import *
from app.models import *


@require_POST
def verificar_login(request):
    cpi = request.POST.get('cpi')
    password = request.POST.get('password')
    
    try:
        # Buscar usuário pelo cpi (id_lider)
        user = Users.objects.get(id_lider=cpi)
        msg = 'Login realizado com sucesso'
        
        print(user)
        if user.password == password:
            lider = user.id_lider
            
            # Armazenar o cpi na sessão
            request.session['cpi'] = cpi
            request.session['user_id'] = user.user_id
            # print(request.session['cpi'], 'salvo na sessão')  # Verifica sessao
            
            # Verificar se o líder é também líder de facção
            is_lider_faccao = Faccao.objects.filter(lider=lider).exists()
            
            # Redirecionar com base no cargo e se é líder de facção
            cargo = lider.cargo.strip()
            
            if cargo == 'COMANDANTE':
                if is_lider_faccao:
                    inserir_log(request.session.get('user_id'), msg)
                    return render(request, 'comandante_lider_faccao.html')
                else:
                    inserir_log(request.session.get('user_id'), msg)
                    return render(request, 'comandante.html')
            elif cargo == 'OFICIAL':
                if is_lider_faccao:
                    inserir_log(request.session.get('user_id'), msg)
                    return render(request, 'oficial_lider_faccao.html')
                else:
                    inserir_log(request.session.get('user_id'), msg)
                    return render(request, 'oficial.html')
            elif cargo == 'CIENTISTA':
                if is_lider_faccao:
                    inserir_log(request.session.get('user_id'), msg)
                    return render(request, 'cientista_lider_faccao.html')
                else:
                    inserir_log(request.session.get('user_id'), msg)
                    return render(request, 'cientista.html')
            else:
                print(f'Cargo não reconhecido: {cargo}')
                mensagem = "Erro ao fazer login: Página não encontrada."
                return render(request, 'pagina_erro.html', {'mensagem': mensagem})
        else:
            print('Senha incorreta')
            mensagem = "Erro ao fazer login: Senha incorreta."
            return render(request, 'pagina_erro.html', {'mensagem': mensagem})

    
    except Users.DoesNotExist:
        print('Usuário não existe')
        mensagem = "Erro ao fazer login: Usuário não encontrado."
        return render(request, 'pagina_erro.html', {'mensagem': mensagem})

    
# LOGOFF
def user_logout(request):
    user = request.session.get('user_id')
    msg = "Logout realizado com sucesso"

    try:
        inserir_log(user, msg)
        return render(request, 'login.html')
    except Exception as e:
        # 
        raise e


# LIDER DE FACCAO -----------------------------------------------------------------------
@require_POST
def view_atualizar_nome_faccao(request):
    faccao_atual = request.POST.get('faccao_atual')
    novo_nome = request.POST.get('novo_nome')
    user = request.session.get('user_id')
    msg = 'Update em Faccao'
    
    try:
        alterar_nome_faccao(faccao_atual, novo_nome)
        inserir_log(user, msg)
        mensagem = f"Sucesso na alteração: Nome da facção '{faccao_atual}' alterado para '{novo_nome}'"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    except Exception as e:
        mensagem_e = f"Erro na alteração: Nome da facção '{faccao_atual}' não pode ser alterado para '{novo_nome}'"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})

@require_POST
def view_indicar_novo_lider(request):
    lider_atual = request.session.get('cpi')
    novo_lider = request.POST.get('novo_lider')
    user = request.session.get('user_id')
    msg = "Update em Faccao"

    if not lider_atual:
        print("Erro: Nenhum líder atual encontrado na sessão.")

    try:
        indicar_novo_lider(lider_atual, novo_lider)
        inserir_log(user, msg)
        mensagem = f"Sucesso na indicação do novo líder: '{novo_lider}'"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    
    except Exception as e:
        mensagem_e = f"Erro na indicação do novo líder: '{novo_lider}'"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})


@require_POST
def view_cadastro_comun_cred(request):
    faccao = request.POST.get('faccao')
    user = request.session.get('user_id')
    msg = "Update em Participa - Cadastro de novas comunidades"
    
    try:
        cadastrar_comunidades_cred(faccao)
        inserir_log(user, msg)
        mensagem = f"Sucesso no credenciamento de comunidades para a Facção '{faccao}'"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    except Exception as e:
        mensagem = f"Erro no credenciamento de comunidades para a Facção '{faccao}'"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem})


@require_POST
def view_remover_faccao_de_nacao(request):
    faccao = request.POST.get('faccao')
    nacao = request.POST.get('nacao')
    user = request.session.get('user_id')
    msg = "Delete em Faccao"
  
    try:
        remover_faccao_de_nacao(faccao, nacao)
        inserir_log(user, msg)
        mensagem = f"Sucesso! Facção '{faccao}' não está mais vinculada à nação '{nacao}'"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    except Exception as e:
        mensagem = f"Erro! Facção '{faccao}' não foi desvinculada da nação '{nacao}'"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem})



# COMANDANTE -----------------------------------------------------------------------

@require_POST
def view_incluir_nacao_federacao(request):
    nacao = request.POST.get('nacao')
    federacao = request.POST.get('federacao')
    user = request.session.get('user_id')
    msg = "Update em Nacao"

    try:
        print('entrou no try')
        incluir_nacao_federacao(nacao, federacao)
        inserir_log(user, msg)
        mensagem = f"Sucesso! Nação '{nacao}' inserida na federação '{federacao}'!"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    except Exception as e:
        print(nacao, federacao, 'erro')
      
        mensagem_e = f"Erro ao incluir nação '{nacao}' na federação '{federacao}'! {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})


@require_POST
def view_inserir_dominancia(request):
    dom_planeta = request.POST.get('dom_planeta')
    dom_nacao = request.POST.get('dom_nacao')
    dom_data_ini = request.POST.get('dom_data_ini')
    dom_data_fim = request.POST.get('dom_data_fim')
    user = request.session.get('user_id')
    msg = "Insert em Dominancia"
    
    try:
        inserir_dominancia(dom_planeta, dom_nacao, dom_data_ini, dom_data_fim)
        inserir_log(user, msg)
        mensagem = f"Sucesso! Dominância inserida: Planeta '{dom_planeta}', Nação '{dom_nacao}', Data inicial '{dom_data_ini}', Data final{dom_data_fim}"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    except Exception as e:
       
        mensagem_e = f"Erro na inserção!"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})



# CIENTISTA ------------------------------------------------------------------------
@require_POST
def view_criar_estrela(request):
    id_estrela = request.POST.get('id_estrela')
    nome = request.POST.get('nome')
    classificacao = request.POST.get('classificacao')
    massa = request.POST.get('massa')
    x = request.POST.get('x')
    y = request.POST.get('y')
    z = request.POST.get('z')
    user = request.session.get('user_id')
    msg = "Insert em Estrela"
   
    print(x, y, z)

  
    if massa is None or massa.strip() == '':
        return render(request, 'pagina_erro.html', {'mensagem': "Massa não pode estar vazia."})
    if x is None or x.strip() == '':
        return render(request, 'pagina_erro.html', {'mensagem': "Coordenada x não pode estar vazia."})
    if y is None or y.strip() == '':
        return render(request, 'pagina_erro.html', {'mensagem': "Coordenada y não pode estar vazia."})
    if z is None or z.strip() == '':
        return render(request, 'pagina_erro.html', {'mensagem': "Coordenada z não pode estar vazia."})

    try:
        
        massa = float(massa)
        x = float(x)
        y = float(y)
        z = float(z)

        print(x, y, z)

     
        criar_estrela(id_estrela, nome, classificacao, massa, x, y, z)
        inserir_log(user, msg)
        mensagem = f"Estrela '{id_estrela}' criada com sucesso!"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    
    except ValueError as ve:
     
        mensagem_e = f"Erro na criação da estrela '{id_estrela}': {str(ve)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})
    
    except Exception as e:
     
        mensagem_e = f"Erro na criação da estrela '{id_estrela}': {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})


@require_POST
def view_ler_dados_estrela(request):
    id_estrela = request.POST.get('estrela')
    user = request.session.get('user_id')
    msg = 'Select em Estrela'

    try:
        result = ler_dados_estrela(id_estrela)
        inserir_log(user, msg)
        return render(request, 'relatorio_estrela.html', {'result': result})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})
    
    
def view_atualizar_estrela(request):
    id_estrela = request.POST.get('id_estrela')
    nome = request.POST.get('nome')
    classificacao = request.POST.get('classificacao')
    massa = request.POST.get('massa')
    x = request.POST.get('x')
    y = request.POST.get('y')
    z = request.POST.get('z')
    user = request.session.get('user_id')
    msg = 'Update em Estrela'

    print(x, y, z)

   
    if massa is None or massa.strip() == '':
        return render(request, 'pagina_erro.html', {'mensagem': "Massa não pode estar vazia."})
    if x is None or x.strip() == '':
        return render(request, 'pagina_erro.html', {'mensagem': "Coordenada x não pode estar vazia."})
    if y is None or y.strip() == '':
        return render(request, 'pagina_erro.html', {'mensagem': "Coordenada y não pode estar vazia."})
    if z is None or z.strip() == '':
        return render(request, 'pagina_erro.html', {'mensagem': "Coordenada z não pode estar vazia."})

    try:
       
        massa = float(massa)
        x = float(x)
        y = float(y)
        z = float(z)

        
        atualizar_estrela(id_estrela, nome, classificacao, massa, x, y, z)
        inserir_log(user, msg)
        mensagem = f"Estrela '{id_estrela}' atualizada com sucesso!"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    
    except ValueError as ve:
       
        mensagem_e = f"Erro na atualização da estrela '{id_estrela}': {str(ve)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})
    
    except Exception as e:
       
        mensagem_e = f"Erro na criação da estrela '{id_estrela}': {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})



@require_POST
def view_deletar_estrela(request):
    id_estrela = request.POST.get('estrela')
    user = request.session.get('user_id')
    msg = 'Delete em Estrela'

    try:
        result = deletar_estrela(id_estrela)
        inserir_log(user, msg)
        mensagem = f"Estrela '{id_estrela}' excluída!"
        return render(request, 'pagina_sucesso.html', {'mensagem': mensagem})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})


# RELATORIOS ==================================================================================================================

# CIENTISTA -----------------------------------------------------------------------
@require_POST
def view_relatorio_estrela(request):

    try:
        result = relatorio_estrela()
        return render(request, 'relatorio_estrela.html', {'result': result})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})


@require_POST
def view_relatorio_planeta(request):
    try:

        result = relatorio_planeta()
        return render(request, 'relatorio_planeta.html', {'result': result})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})

@require_POST
def view_relatorio_sistema(request):

    try:
        result = relatorio_sistema()
        return render(request, 'relatorio_sistema.html', {'result': result})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})



# OFICIAL -----------------------------------------------------------------------
@require_POST
def view_relatorio_oficial_sistema(request):
    data_ini = request.POST.get('data_ini')
    data_fim = request.POST.get('data_fim')
    cpi_lider = request.session.get('cpi')

    try:
        result = relatorio_oficial_sistema(cpi_lider, data_ini, data_fim)
        print(result)
        return render(request, 'relatorio_oficial_sistema.html', {'result': result})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})

@require_POST
def view_relatorio_oficial_faccao(request):
    data_ini = request.POST.get('data_ini')
    data_fim = request.POST.get('data_fim')
    cpi_lider = request.session.get('cpi')

    try:
        result = relatorio_oficial_faccao(cpi_lider, data_ini, data_fim)
        return render(request, 'relatorio_oficial_faccao.html', {'result': result})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})
    
@require_POST
def view_relatorio_oficial_especie(request):
    data_ini = request.POST.get('data_ini')
    data_fim = request.POST.get('data_fim')
    cpi_lider = request.session.get('cpi')

    try:
        result = relatorio_oficial_especie(cpi_lider, data_ini, data_fim)
        return render(request, 'relatorio_oficial_especie.html', {'result': result})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})
    
@require_POST
def view_relatorio_oficial_planeta(request):
    data_ini = request.POST.get('data_ini')
    data_fim = request.POST.get('data_fim')
    cpi_lider = request.session.get('cpi')

    try:
        result = relatorio_oficial_planeta(cpi_lider, data_ini, data_fim)
        return render(request, 'relatorio_oficial_planeta.html', {'result': result})
    
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})



# LIDER -----------------------------------------------------------------------

@require_POST
def view_gerar_relatorio_lider(request):
    if request.method == 'POST':
        nome_faccao = request.POST.get('nome_faccao')
        

        try:
            result = gerar_relatorio_lider(nome_faccao)
            return render(request, 'relatorio_lider_comunidades.html', {'result': result})
            
        except Exception as e:
            mensagem_e = f"Erro: {str(e)}"
            return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})


# COMANDANTE -----------------------------------------------------------------------


@require_POST
def view_gerar_relatorio_comandante(request):
    cpi_lider = request.session.get('cpi')
        
    try:
        result = gerar_relatorio_comandante(cpi_lider)
        print(result)  # Verifique os resultados no console para depuração
        return render(request, 'relatorio_comandante.html', {'result': result})
        
    except Exception as e:
        mensagem_e = f"Erro: {str(e)}"
        return render(request, 'pagina_erro.html', {'mensagem': mensagem_e})
