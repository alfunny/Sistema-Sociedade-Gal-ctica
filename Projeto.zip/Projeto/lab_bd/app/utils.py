from django.db import connection
from django.shortcuts import render
from django.views.decorators.http import require_POST
from app.models import *

    
# LOG
def inserir_log(user, msg):
    cursor = connection.cursor()
    try:
        cursor.callproc('inserir_log', [user, msg])
        connection.commit()
        cursor.close()
    except Exception as e:
        # 
        raise e

#  LIDER DE FACCAO -----------------------------------------------------------------------
def alterar_nome_faccao(faccao_atual, novo_nome):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_lider.alterar_nome_faccao', [faccao_atual, novo_nome])
        connection.commit()
        cursor.close()
    except Exception as e:
        # 
        raise e

def indicar_novo_lider(lider_atual, novo_lider):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_lider.indicar_lider', [lider_atual, novo_lider])
        connection.commit()
        cursor.close()
    except Exception as e:
        # 
        raise e

def cadastrar_comunidades_cred(faccao):
    cursor = connection.cursor()
    print(cursor)
    try:
        cursor.callproc('pacote_lider.inserir_view_ger_comunidades', [faccao])
        print(faccao)
        connection.commit()
        cursor.close()
    except Exception as e:
        raise e
    

def remover_faccao_de_nacao(faccao, nacao):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_lider.remover_faccao', [faccao, nacao])
        connection.commit()
        cursor.close()
    except Exception as e:
        raise e
     


#  COMANDANTE -----------------------------------------------------------------------     
def inserir_dominancia(dom_planeta, dom_nacao, dom_data_ini, dom_data_fim):
    cursor = connection.cursor()
    try:
        cursor.callproc('inserir_dominancia', [dom_planeta, dom_nacao, dom_data_ini, dom_data_fim])
        connection.commit()
        cursor.close()
    except Exception as e:
        raise e

def incluir_nacao_federacao(nacao, federacao):
    cursor = connection.cursor()
    try:
        cursor.callproc('incluir_nacao_federacao', [nacao, federacao])
        print('depois da callproc')
        cursor.commit()
        cursor.close()
    except Exception as e:
        raise e

#  CIENTISTA ------------------------------------------------------------------------
def criar_estrela(id_estrela, nome, classificacao, massa, x, y, z):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_cientista.criar_estrela', [id_estrela, nome, classificacao, massa, x, y, z])
        connection.commit()
        cursor.close()
    except Exception as e:
        raise e

def ler_dados_estrela(id_estrela):
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('pacote_cientista.ler_dados_estrela', [id_estrela, out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e
    

def atualizar_estrela(id_estrela, nome, classificacao, massa, x, y, z):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_cientista.atualizar_estrela', [id_estrela, nome, classificacao, massa, x, y, z])
        connection.commit()
        cursor.close()
    except Exception as e:
        raise e



def deletar_estrela(id_estrela):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_cientista.deletar_estrela', [id_estrela]),
        connection.commit()
        cursor.close()
    except Exception as e:
        raise e



# RELATORIOS =======================================================================================================

#  CIENTISTA ------------------------------------------------------------------------


def relatorio_estrela():
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('pacote_relatorio_cientista.relatorio_estrela', [out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e

def relatorio_planeta():
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('pacote_relatorio_cientista.relatorio_planeta', [out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e

def relatorio_sistema():
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('pacote_relatorio_cientista.relatorio_sistema', [out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e


# OFICIAL ------------------------------------------------------------------------
def relatorio_oficial_sistema(cpi_lider, data_ini, data_fim):
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('pacote_relatorio_oficial.relatorio_oficial_sistema', [cpi_lider, data_ini, data_fim, out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e

def relatorio_oficial_faccao(cpi_lider, data_ini, data_fim):
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('pacote_relatorio_oficial.relatorio_oficial_faccao', [cpi_lider, data_ini, data_fim, out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e
    
def relatorio_oficial_especie(cpi_lider, data_ini, data_fim):
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('pacote_relatorio_oficial.relatorio_oficial_especie', [cpi_lider, data_ini, data_fim, out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e
    
def relatorio_oficial_planeta(cpi_lider, data_ini, data_fim):
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('pacote_relatorio_oficial.relatorio_oficial_planeta', [cpi_lider, data_ini, data_fim, out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e
    

# LIDER --------------------------------------------------------------------------------------------------

def gerar_relatorio_lider(nome_faccao):
    try:
        with connection.cursor() as cursor:
            out_cursor = connection.connection.cursor()
            cursor.callproc('relatorio_comunidades', [nome_faccao, out_cursor])

            # Fetch all rows from cursor
            result = out_cursor.fetchall()
            out_cursor.close()
            
            return result
            
    except Exception as e:
        raise e
    

# COMANDANTE -----------------------------------------------------------------------------------------------
# def gerar_relatorio_comandante(cpi_lider):
#     try:
#         with connection.cursor() as cursor:
#             out_cursor = connection.connection.cursor()
#             cursor.callproc('listar_dominancia_planetas', [cpi_lider, out_cursor])

#             # Fetch all rows from cursor
#             result = out_cursor.fetchall()
#             out_cursor.close()
            
#             return result
            
#     except Exception as e:
#         raise e    

def gerar_relatorio_comandante(cpi_lider):
    try:
        with connection.cursor() as cursor:
    
            out_cursor = cursor.connection.cursor()

            cursor.callproc('listar_dominancia_planetas', [cpi_lider, out_cursor])

            result = out_cursor.fetchall()
            
            out_cursor.close()

            
            for row in result:
                print(f"Raw row: {row}")

           
            processed_result = []
            for row in result:
                processed_row = list(row) 
                
                if len(row) > 6:
                    processed_row[6] = int(row[6]) if row[6] is not None else None 
                if len(row) > 4:
                    processed_row[4] = int(row[4]) if row[4] is not None else None 
                if len(row) > 5:
                    processed_row[5] = int(row[5]) if row[5] is not None else None  

                processed_result.append(processed_row)
                
                print(f"Processed row: {processed_row}")

            return processed_result

    except Exception as e:
        raise e

