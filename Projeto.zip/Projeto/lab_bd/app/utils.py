from django.db import connection

def alterar_nome_faccao(faccao_atual, novo_nome):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_func_lider.alterar_nome_faccao', [faccao_atual, novo_nome])
        connection.commit()  # Confirma a transação no banco de dados Oracle
        cursor.close()
    except Exception as e:
        # Trate qualquer exceção que possa ocorrer durante a execução do procedimento
        raise e

def cadastrar_comunidades_cred(faccao):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_func_lider.inserir_view_ger_comunidades' [faccao])
        connection.commit()
        cursor.close()
    except Exception as e:
        raise e
    

def remover_faccao_de_nacao(faccao, nacao):
    cursor = connection.cursor()
    try:
        cursor.callproc('pacote_func_lider.remover_faccao' [faccao, nacao])
        connection.commit()
        cursor.close()
    except Exception as e:
        raise e
    