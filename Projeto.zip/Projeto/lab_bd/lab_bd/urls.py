"""
URL configuration for lab_bd project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app.views import *
from django.views.generic import TemplateView
# from lab_bd.app import views

urlpatterns = [
    path('admin/', admin.site.urls), # Django admin site
    
    path('', TemplateView.as_view(template_name="login.html"), name='login'),
    path('verificar_login/', verificar_login, name='verificar_login'),
    # path('pagina_lider/', verificar_login, name='pagina_lider'),

    # path('', verificar_login, name='login'),
    path('pagina_comandante/', verificar_login, name='pagina_comandante'),
    path('pagina_cientista/', verificar_login, name='pagina_cientista'),
    path('pagina_oficial/', verificar_login, name='pagina_oficial'),



    # URLS LIDER DE FACCAO ----------------------------------------------------------------------
    # ATUALIZAR FACCAO
    path('alterar_nome_faccao/', view_atualizar_nome_faccao, name='view_atualizar_nome_faccao'),
    path('pagina_erro/', view_atualizar_nome_faccao, name='pagina_erro'),
    path('pagina_sucesso/', view_atualizar_nome_faccao, name='pagina_sucesso'),

    # CADASTRAR COMUNIDADES CREDENCIADAS
    path('cadastro_comun_cred/', view_cadastro_comun_cred, name='view_cadastro_comun_cred'),
    path('pagina_erro/', view_cadastro_comun_cred, name='pagina_erro'),
    path('pagina_sucesso/', view_cadastro_comun_cred, name='pagina_sucesso'),

    # REMOVER FACCAO DE NACAO
    path('remover_faccao_de_nacao/', view_remover_faccao_de_nacao, name='view_remover_faccao_de_nacao'),
    path('pagina_erro/', view_remover_faccao_de_nacao, name='pagina_erro'),
    path('pagina_sucesso/', view_remover_faccao_de_nacao, name='pagina_sucesso'),
    
    # path('index/', TemplateView.as_view(template_name="index.html")),
    path('resultado_relatorio/', gerar_relatorio_view, name='gerar_relatorio'),
]



