"""
URL configuration for lab_bd project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app.views import *
from django.views.generic import TemplateView


urlpatterns = [
    path('admin/', admin.site.urls), # Django admin site
    
    path('', TemplateView.as_view(template_name="login.html"), name='login'),
    path('verificar_login/', verificar_login, name='verificar_login'),
    path('logout/', user_logout, name='user_logout'),

    # URLS LIDER DE FACCAO ----------------------------------------------------------------------
    # atualizar faccao
    path('alterar_nome_faccao/', view_atualizar_nome_faccao, name='view_atualizar_nome_faccao'),
    path('pagina_erro/', view_atualizar_nome_faccao, name='pagina_erro'),
    path('pagina_sucesso/', view_atualizar_nome_faccao, name='pagina_sucesso'),

    # indicar novo lider
    path('indicar_novo_lider/', view_indicar_novo_lider, name='view_indicar_novo_lider'),
    path('pagina_erro/', view_indicar_novo_lider, name='pagina_erro'),
    path('pagina_sucesso/', view_indicar_novo_lider, name='pagina_sucesso'),

    # cadastrar comunidades credenciadas
    path('cadastro_comun_cred/', view_cadastro_comun_cred, name='view_cadastro_comun_cred'),
    path('pagina_erro/', view_cadastro_comun_cred, name='pagina_erro'),
    path('pagina_sucesso/', view_cadastro_comun_cred, name='pagina_sucesso'),

    # remover faccao de nacao
    path('remover_faccao_de_nacao/', view_remover_faccao_de_nacao, name='view_remover_faccao_de_nacao'),
    path('pagina_erro/', view_remover_faccao_de_nacao, name='pagina_erro'),
    path('pagina_sucesso/', view_remover_faccao_de_nacao, name='pagina_sucesso'),
    
    #  relatorio lider
    path('gerar_relatorio_lider/', view_gerar_relatorio_lider, name='view_gerar_relatorio_lider'),
    path('pagina_erro/', view_gerar_relatorio_lider, name="pagina_erro"),
    path('pagina_sucesso/', view_gerar_relatorio_lider, name='pagina_sucesso'),





    # URLS COMANDANTE ----------------------------------------------------------------------
    path('view_inserir_dominancia/', view_inserir_dominancia, name='view_inserir_dominancia'),
    path('pagina_erro/', view_inserir_dominancia, name='pagina_erro'),
    path('pagina_sucesso/', view_inserir_dominancia, name='pagina_sucesso'),

    path('incluir_nacao_federacao/', view_incluir_nacao_federacao, name='view_incluir_nacao_federacao'),
    path('pagina_erro/', view_incluir_nacao_federacao, name='pagina_erro'),
    path('pagina_sucesso/', view_incluir_nacao_federacao, name='pagina_sucesso'),


    # URLS CIENTISTA ----------------------------------------------------------------------
    #  criar estrela
    path('criar_estrela/', view_criar_estrela, name='view_criar_estrela'),
    path('pagina_erro/', view_criar_estrela, name='pagina_erro'),
    path('pagina_sucesso/', view_criar_estrela, name='pagina_sucesso'),

    path('ler_dados_estrela/', view_ler_dados_estrela, name='view_ler_dados_estrela'),
    path('pagina_erro/', view_ler_dados_estrela, name='pagina_erro'),
    path('pagina_sucesso/', view_ler_dados_estrela, name='pagina_sucesso'),

    path('atualizar_estrela/', view_atualizar_estrela, name='view_atualizar_estrela'),
    path('pagina_erro/', view_atualizar_estrela, name='pagina_erro'),
    path('pagina_sucesso/', view_atualizar_estrela, name='pagina_sucesso'),

    path('deletar_estrela/', view_deletar_estrela, name='view_deletar_estrela'),
    path('pagina_erro/', view_deletar_estrela, name='pagina_erro'),
    path('pagina_sucesso/', view_deletar_estrela, name='pagina_sucesso'),


    # relatorio oficial
    path('relatorio_sistema/', view_relatorio_oficial_sistema, name='view_relatorio_oficial_sistema'),
    path('pagina_erro/', view_relatorio_oficial_sistema, name='pagina_erro'),
    path('pagina_sucesso/', view_relatorio_oficial_sistema, name='relatorio_oficial_sistema'),

    path('relatorio_faccao/', view_relatorio_oficial_faccao, name='view_relatorio_oficial_faccao'),
    path('pagina_erro/', view_relatorio_oficial_faccao, name='pagina_erro'),
    path('pagina_sucesso/', view_relatorio_oficial_faccao, name='relatorio_oficial_faccao'),

    path('relatorio_especie/', view_relatorio_oficial_especie, name='view_relatorio_oficial_especie'),
    path('pagina_erro/', view_relatorio_oficial_especie, name='pagina_erro'),
    path('pagina_sucesso/', view_relatorio_oficial_especie, name='relatorio_oficial_especie'),

    path('relatorio_planeta/', view_relatorio_oficial_planeta, name='view_relatorio_oficial_planeta'),
    path('pagina_erro/', view_relatorio_oficial_planeta, name='pagina_erro'),
    path('pagina_sucesso/', view_relatorio_oficial_planeta, name='relatorio_oficial_planeta'),


    # relatorio cientista
    path('relatorio_estrela/', view_relatorio_estrela, name='view_relatorio_estrela'),
    path('pagina_erro/', view_relatorio_estrela, name='pagina_erro'),
    path('pagina_sucesso/', view_relatorio_estrela, name='relatorio_estrela'),
    
    path('relatorio_planeta/', view_relatorio_planeta, name='view_relatorio_planeta'),
    path('pagina_erro/', view_relatorio_planeta, name='pagina_erro'),
    path('pagina_sucesso/', view_relatorio_planeta, name='relatorio_planeta'),
    
    path('relatorio_sistema/', view_relatorio_sistema, name='view_relatorio_sistema'),
    path('pagina_erro/', view_relatorio_sistema, name='pagina_erro'),
    path('pagina_sucesso/', view_relatorio_sistema, name='relatorio_sistema'),

    # relatorio comandante
    path('relatorio_comandante/', view_gerar_relatorio_comandante, name='view_gerar_relatorio_comandante'),
    path('pagina_erro/', view_gerar_relatorio_comandante, name='pagina_erro'),
    path('pagina_sucesso/', view_gerar_relatorio_comandante, name='relatorio_comandante'),
    
    
]
