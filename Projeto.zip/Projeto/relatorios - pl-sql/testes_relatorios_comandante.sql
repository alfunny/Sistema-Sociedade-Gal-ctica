-- impressao listar dominancia ===========================================================================================
DECLARE
    v_cursor_dominancia SYS_REFCURSOR;
    v_planeta DOMINANCIA.PLANETA%TYPE;
    v_nacao DOMINANCIA.NACAO%TYPE;
    v_data_ini DOMINANCIA.DATA_INI%TYPE;
    v_data_fim DOMINANCIA.DATA_FIM%TYPE;
    v_qtd_comunidades NUMBER;
    v_qtd_especies NUMBER;
    v_total_habitantes NUMBER;
    v_planeta_informacoes SYS_REFCURSOR;
    v_cpi_lider CONSTANT LIDER.CPI%TYPE := '000.000.000-07';
BEGIN
    -- Executa o procedimento para listar a dominância dos planetas
    listar_dominancia_planetas(v_cpi_lider, v_cursor_dominancia);

    -- Exibe a lista de dominância de planetas
    DBMS_OUTPUT.PUT_LINE('LISTA DE DOMINÂNCIA DE PLANETAS');
    DBMS_OUTPUT.PUT_LINE('----------------------------------------------');

    LOOP
        FETCH v_cursor_dominancia INTO v_planeta, v_nacao, v_data_ini, v_data_fim;
        EXIT WHEN v_cursor_dominancia%NOTFOUND;

        DBMS_OUTPUT.PUT_LINE('PLANETA: ' || v_planeta);
        DBMS_OUTPUT.PUT_LINE('  Nação Dominante: ' || v_nacao);
        DBMS_OUTPUT.PUT_LINE('  Data de Início da Vigência: ' || TO_CHAR(v_data_ini, 'DD-MM-YYYY'));
        
        IF v_data_fim IS NULL THEN
            DBMS_OUTPUT.PUT_LINE('  Data de Fim da Vigência: Ativo');
        ELSE
            DBMS_OUTPUT.PUT_LINE('  Data de Fim da Vigência: ' || TO_CHAR(v_data_fim, 'DD-MM-YYYY'));
        END IF;

        -- Obtém informações adicionais do planeta
        v_planeta_informacoes := obter_informacoes_planeta(v_planeta);
        FETCH v_planeta_informacoes INTO 
            v_qtd_comunidades, v_qtd_especies, v_total_habitantes;
        CLOSE v_planeta_informacoes;

        DBMS_OUTPUT.PUT_LINE('  Quantidade de Comunidades: ' || v_qtd_comunidades);
        DBMS_OUTPUT.PUT_LINE('  Quantidade de Espécies: ' || v_qtd_especies);
        DBMS_OUTPUT.PUT_LINE('  Total de Habitantes: ' || v_total_habitantes);
        DBMS_OUTPUT.PUT_LINE('');
       	DBMS_OUTPUT.PUT_LINE('----------------------------------------------');
    END LOOP;
    CLOSE v_cursor_dominancia;

END;




 impressao relatorio estrategico ===========================================================================================
DECLARE
    v_cursor_estrategico SYS_REFCURSOR;
    v_cursor_dominancia SYS_REFCURSOR;
    v_planeta DOMINANCIA.PLANETA%TYPE;
    v_nacao DOMINANCIA.NACAO%TYPE;
    v_data_ini DOMINANCIA.DATA_INI%TYPE;
    v_data_fim DOMINANCIA.DATA_FIM%TYPE;
    v_qtd_comunidades NUMBER;
    v_qtd_especies NUMBER;
    v_total_habitantes NUMBER;
    v_planeta_informacoes SYS_REFCURSOR;
    v_cpi_lider CONSTANT LIDER.CPI%TYPE := '000.000.000-07';
BEGIN
    -- Executa o procedimento para gerar o relatório estratégico
    relatorio_estrategico(v_cpi_lider, v_cursor_estrategico);

    -- Exibe o relatório estratégico
    DBMS_OUTPUT.PUT_LINE('Relatório Estratégico');
    DBMS_OUTPUT.PUT_LINE('------------------------------------');
    
    LOOP
        FETCH v_cursor_estrategico INTO v_planeta, v_nacao, v_data_ini, v_data_fim;
        EXIT WHEN v_cursor_estrategico%NOTFOUND;
        
        DBMS_OUTPUT.PUT_LINE('PLANETA: ' || v_planeta);
        DBMS_OUTPUT.PUT_LINE('Nação Dominante: ' || v_nacao);
        DBMS_OUTPUT.PUT_LINE('Data de Início da Vigência: ' || TO_CHAR(v_data_ini, 'DD-MM-YYYY'));
        IF v_data_fim IS NULL THEN
            DBMS_OUTPUT.PUT_LINE('Data de Fim da Vigência: Ativo');
        ELSE
            DBMS_OUTPUT.PUT_LINE('Data de Fim da Vigência: ' || TO_CHAR(v_data_fim, 'DD-MM-YYYY'));
        END IF;
        DBMS_OUTPUT.PUT_LINE('');
    END LOOP;
    CLOSE v_cursor_estrategico;

    -- Executa o procedimento para listar a dominância dos planetas
    listar_dominancia_planetas(v_cpi_lider, v_cursor_dominancia);

    -- Exibe a lista de dominância de planetas
	dbms_output.put_line(' ');
    DBMS_OUTPUT.PUT_LINE('Lista de Dominância de Planetas');
    DBMS_OUTPUT.PUT_LINE('------------------------------------');

    LOOP
        FETCH v_cursor_dominancia INTO v_planeta, v_nacao, v_data_ini, v_data_fim;
        EXIT WHEN v_cursor_dominancia%NOTFOUND;

        DBMS_OUTPUT.PUT_LINE('PLANETA: ' || v_planeta);
        DBMS_OUTPUT.PUT_LINE('Nação Dominante: ' || v_nacao);
        DBMS_OUTPUT.PUT_LINE('Data de Início da Vigência: ' || TO_CHAR(v_data_ini, 'DD-MM-YYYY'));
        IF v_data_fim IS NULL THEN
            DBMS_OUTPUT.PUT_LINE('Data de Fim da Vigência: Ativo');
        ELSE
            DBMS_OUTPUT.PUT_LINE('Data de Fim da Vigência: ' || TO_CHAR(v_data_fim, 'DD-MM-YYYY'));
        END IF;

        -- Obtém informações adicionais do planeta
        v_planeta_informacoes := obter_informacoes_planeta(v_planeta);
        FETCH v_planeta_informacoes INTO 
            v_qtd_comunidades, v_qtd_especies, v_total_habitantes;
        CLOSE v_planeta_informacoes;

        DBMS_OUTPUT.PUT_LINE('Quantidade de Comunidades: ' || v_qtd_comunidades);
        DBMS_OUTPUT.PUT_LINE('Quantidade de Espécies: ' || v_qtd_especies);
        DBMS_OUTPUT.PUT_LINE('Total de Habitantes: ' || v_total_habitantes);
        DBMS_OUTPUT.PUT_LINE('');
    END LOOP;
    CLOSE v_cursor_dominancia;

END;

