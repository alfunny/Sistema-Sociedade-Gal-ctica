-- O total de habitantes não estava sendo retornado 

SELECT * FROM user_errors;
CREATE OR REPLACE PACKAGE pacote_relatorio_oficial AS

    -- sistema
    PROCEDURE relatorio_oficial_sistema(
        p_cpi_lider lider.cpi%TYPE,
        p_data_ini DATE,
        p_data_fim DATE,
        p_out_cursor OUT SYS_REFCURSOR
    );

    -- facção
    PROCEDURE relatorio_oficial_faccao(
        p_cpi_lider lider.cpi%TYPE,
        p_data_ini DATE,
        p_data_fim DATE,
        p_out_cursor OUT SYS_REFCURSOR
    );

    -- espécie
    PROCEDURE relatorio_oficial_especie(
        p_cpi_lider lider.cpi%TYPE,
        p_data_ini DATE,
        p_data_fim DATE,
        p_out_cursor OUT SYS_REFCURSOR
    );

    -- planeta
    PROCEDURE relatorio_oficial_planeta(
        p_cpi_lider lider.cpi%TYPE,
        p_data_ini DATE,
        p_data_fim DATE,
        p_out_cursor OUT SYS_REFCURSOR
    );

END pacote_relatorio_oficial;


CREATE OR REPLACE PACKAGE BODY pacote_relatorio_oficial AS

PROCEDURE relatorio_oficial_sistema(
    p_cpi_lider lider.cpi%TYPE,
    p_data_ini DATE,
    p_data_fim DATE,
    p_out_cursor OUT SYS_REFCURSOR
) AS
    v_nacao nacao.nome%TYPE;
   	v_count NUMBER;
   
    e_data_inicial_maior_que_final EXCEPTION;
    pragma exception_init(e_data_inicial_maior_que_final, -20001);
BEGIN
    -- Verificar se a data inicial é menor que a data final
    IF p_data_ini >= p_data_fim THEN
        raise e_data_inicial_maior_que_final;
    END IF;

    -- Obter a nação do líder
    SELECT nacao INTO v_nacao FROM lider WHERE cpi = p_cpi_lider;

    -- Abrir cursor para retornar os resultados
    OPEN p_out_cursor FOR
        SELECT
            sistema,
            estrela,
            planeta,
            especie,
            comunidade,
            data_ini,
            data_fim,
            qtd_habitantes,
            SUM(qtd_habitantes) OVER (PARTITION BY planeta) AS total_habitantes_planeta,
            ROUND(AVG(qtd_habitantes) OVER (PARTITION BY planeta)) AS media_habitantes_planeta,
            SUM(CASE WHEN data_ini <= p_data_ini AND (data_fim IS NULL OR data_fim > p_data_ini) THEN qtd_habitantes ELSE 0 END) OVER (PARTITION BY planeta) AS total_habitantes_ini,
            SUM(CASE WHEN data_ini <= p_data_fim AND (data_fim IS NULL OR data_fim > p_data_fim) THEN qtd_habitantes ELSE 0 END) OVER (PARTITION BY planeta) AS total_habitantes_fim
        FROM view_relatorio_sistema
        WHERE nacao = v_nacao
        ORDER BY sistema, estrela, planeta;
       
       -- Verifique se o cursor está vazio
    IF p_out_cursor%NOTFOUND THEN
        CLOSE p_out_cursor;
        RAISE NO_DATA_FOUND;
    END IF;
       
EXCEPTION
    WHEN e_data_inicial_maior_que_final THEN
        raise_application_error(-20001, 'A data inicial deve ser menor que a data final.');
    WHEN NO_DATA_FOUND THEN
        raise_application_error(-20002, 'Nenhum dado foi encontrado. Talvez não tenha registros.');
    WHEN OTHERS THEN
        raise_application_error(-20004, 'Erro: ' || SQLERRM);
END relatorio_oficial_sistema;


    -- Procedimento para relatório facção -----------------------------------------------
    PROCEDURE relatorio_oficial_faccao(
    p_cpi_lider lider.cpi%TYPE,
    p_data_ini DATE,
    p_data_fim DATE,
    p_out_cursor OUT SYS_REFCURSOR
) AS
    v_nacao nacao.nome%TYPE;
   	v_count NUMBER;
   
    e_data_inicial_maior_que_final EXCEPTION;
    pragma exception_init(e_data_inicial_maior_que_final, -20001);
BEGIN
    -- Verificar se a data inicial é menor que a data final
    IF p_data_ini >= p_data_fim THEN
        raise e_data_inicial_maior_que_final;
    END IF;

    -- Obter a nação do líder
    SELECT nacao INTO v_nacao FROM lider WHERE cpi = p_cpi_lider;

    -- Abrir cursor para retornar os resultados
    OPEN p_out_cursor FOR
        SELECT
            faccao,
            lider,
            planeta,
            especie,
            comunidade,
            data_ini,
            data_fim,
            qtd_habitantes,
            SUM(qtd_habitantes) OVER (PARTITION BY planeta) AS total_habitantes_planeta,
            ROUND(AVG(qtd_habitantes) OVER (PARTITION BY planeta)) AS media_habitantes_planeta,
            SUM(CASE WHEN data_ini <= p_data_ini AND (data_fim IS NULL OR data_fim > p_data_ini) THEN qtd_habitantes ELSE 0 END) OVER (PARTITION BY planeta) AS total_habitantes_ini,
            SUM(CASE WHEN data_ini <= p_data_fim AND (data_fim IS NULL OR data_fim > p_data_fim) THEN qtd_habitantes ELSE 0 END) OVER (PARTITION BY planeta) AS total_habitantes_fim
        FROM view_relatorio_faccao
        WHERE nacao = v_nacao
        ORDER BY faccao, lider, planeta;
       
       -- Verifique se o cursor está vazio
    IF p_out_cursor%NOTFOUND THEN
        CLOSE p_out_cursor;
        RAISE NO_DATA_FOUND;
    END IF;
   
EXCEPTION
    WHEN e_data_inicial_maior_que_final THEN
        raise_application_error(-20001, 'A data inicial deve ser menor que a data final.');
    WHEN NO_DATA_FOUND THEN
        raise_application_error(-20002, 'Nenhum dado foi encontrado. Talvez não tenha registros.');
    WHEN OTHERS THEN
        raise_application_error(-20004, 'Erro: ' || SQLERRM);
END relatorio_oficial_faccao;

    -- Procedimento para relatório espécie -----------------------------------------------
    PROCEDURE relatorio_oficial_especie(
    p_cpi_lider lider.cpi%TYPE,
    p_data_ini DATE,
    p_data_fim DATE,
    p_out_cursor OUT SYS_REFCURSOR
) AS
    v_nacao nacao.nome%TYPE;
   	v_count NUMBER;
   
    e_data_inicial_maior_que_final EXCEPTION;
    pragma exception_init(e_data_inicial_maior_que_final, -20001);
BEGIN
    -- Verificar se a data inicial é menor que a data final
    IF p_data_ini >= p_data_fim THEN
        raise e_data_inicial_maior_que_final;
    END IF;

    -- Obter a nação do líder
    SELECT nacao INTO v_nacao FROM lider WHERE cpi = p_cpi_lider;

    -- Abrir cursor para retornar os resultados
    OPEN p_out_cursor FOR
        SELECT
            especie,
            planeta_or,
            planeta,
            comunidade,
            data_ini,
            data_fim,
            qtd_habitantes,
            SUM(qtd_habitantes) OVER (PARTITION BY planeta) AS total_habitantes_planeta,
            ROUND(AVG(qtd_habitantes) OVER (PARTITION BY planeta)) AS media_habitantes_planeta,
            SUM(CASE WHEN data_ini <= p_data_ini AND (data_fim IS NULL OR data_fim > p_data_ini) THEN qtd_habitantes ELSE 0 END) OVER (PARTITION BY planeta) AS total_habitantes_ini,
            SUM(CASE WHEN data_ini <= p_data_fim AND (data_fim IS NULL OR data_fim > p_data_fim) THEN qtd_habitantes ELSE 0 END) OVER (PARTITION BY planeta) AS total_habitantes_fim
        FROM view_relatorio_especie
        WHERE nacao = v_nacao
        ORDER BY especie, planeta_or, planeta;
       
       -- Verifique se o cursor está vazio
    IF p_out_cursor%NOTFOUND THEN
        CLOSE p_out_cursor;
        RAISE NO_DATA_FOUND;
    END IF;
   
EXCEPTION
    WHEN e_data_inicial_maior_que_final THEN
        raise_application_error(-20001, 'A data inicial deve ser menor que a data final.');
    WHEN NO_DATA_FOUND THEN
        raise_application_error(-20002, 'Nenhum dado foi encontrado. Talvez não tenha registros.');
    WHEN OTHERS THEN
        raise_application_error(-20004, 'Erro: ' || SQLERRM);
END relatorio_oficial_especie;


    -- Procedimento para relatório planeta --------------------------------------------
    PROCEDURE relatorio_oficial_planeta(
    p_cpi_lider lider.cpi%TYPE,
    p_data_ini DATE,
    p_data_fim DATE,
    p_out_cursor OUT SYS_REFCURSOR
) AS
    v_nacao nacao.nome%TYPE;
   	v_count NUMBER;
   
    e_data_inicial_maior_que_final EXCEPTION;
    pragma exception_init(e_data_inicial_maior_que_final, -20001);
BEGIN
    -- Verificar se a data inicial é menor que a data final
    IF p_data_ini >= p_data_fim THEN
        raise e_data_inicial_maior_que_final;
    END IF;

    -- Obter a nação do líder
    SELECT nacao INTO v_nacao FROM lider WHERE cpi = p_cpi_lider;

    -- Abrir cursor para retornar os resultados
    OPEN p_out_cursor FOR
        SELECT
            planeta,
            nacao,
            especie,
            comunidade,
            data_ini,
            data_fim,
            qtd_habitantes,
            SUM(qtd_habitantes) OVER (PARTITION BY planeta) AS total_habitantes_planeta,
            ROUND(AVG(qtd_habitantes) OVER (PARTITION BY planeta)) AS media_habitantes_planeta,
            SUM(CASE WHEN data_ini <= p_data_ini AND (data_fim IS NULL OR data_fim > p_data_ini) THEN qtd_habitantes ELSE 0 END) OVER (PARTITION BY planeta) AS total_habitantes_ini,
            SUM(CASE WHEN data_ini <= p_data_fim AND (data_fim IS NULL OR data_fim > p_data_fim) THEN qtd_habitantes ELSE 0 END) OVER (PARTITION BY planeta) AS total_habitantes_fim
        FROM view_relatorio_planeta
        WHERE nacao = v_nacao
        ORDER BY planeta, nacao;
       
       -- Verifique se o cursor está vazio
    IF p_out_cursor%NOTFOUND THEN
        CLOSE p_out_cursor;
        RAISE NO_DATA_FOUND;
    END IF;
       
EXCEPTION
    WHEN e_data_inicial_maior_que_final THEN
        raise_application_error(-20001, 'A data inicial deve ser menor que a data final.');
    WHEN NO_DATA_FOUND THEN
        raise_application_error(-20002, 'Nenhum dado foi encontrado. Talvez não tenha registros.');
    WHEN OTHERS THEN
        raise_application_error(-20004, 'Erro: ' || SQLERRM);
END relatorio_oficial_planeta;

END pacote_relatorio_oficial;
