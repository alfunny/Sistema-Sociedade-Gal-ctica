-- ========================= SISTEMA =========================
CREATE OR REPLACE VIEW view_relatorio_sistema AS
SELECT 
    s.nome AS sistema, 
    s.estrela, 
    d.nacao,
    h.planeta, 
    c.especie, 
    c.nome AS comunidade, 
    c.qtd_habitantes,
    h.data_ini, 
    h.data_fim
FROM 
    sistema s
    JOIN orbita_planeta op ON s.estrela = op.estrela
    JOIN dominancia d ON op.planeta = d.planeta
    JOIN habitacao h ON d.planeta = h.planeta
    JOIN comunidade c ON h.especie = c.especie AND h.comunidade = c.nome
WHERE
    (d.data_fim IS NULL OR d.data_fim > SYSDATE);


-- ========================= FACCAO =========================
CREATE OR REPLACE VIEW view_relatorio_faccao AS
SELECT 
    f.nome AS faccao, 
    f.lider, 
    d.nacao,
    h.planeta, 
    c.especie, 
    c.nome AS comunidade, 
    c.qtd_habitantes,
    h.data_ini, 
    h.data_fim
FROM 
    faccao f
    JOIN nacao_faccao nf ON f.nome = nf.faccao
    JOIN nacao n ON nf.nacao = n.nome
    JOIN dominancia d ON n.nome = d.nacao
    JOIN habitacao h ON d.planeta = h.planeta
    JOIN comunidade c ON h.especie = c.especie AND h.comunidade = c.nome
WHERE
    (d.data_fim IS NULL OR d.data_fim > SYSDATE);

-- ========================= ESPECIE =========================
CREATE OR REPLACE VIEW view_relatorio_especie AS
SELECT 
    e.nome AS especie, 
    e.planeta_or, 
    d.nacao,
    h.planeta, 
    c.nome AS comunidade, 
    c.qtd_habitantes,
    h.data_ini, 
    h.data_fim
FROM 
    especie e
    JOIN habitacao h ON e.nome = h.especie
    JOIN dominancia d ON h.planeta = d.planeta
    JOIN comunidade c ON h.especie = c.especie AND h.comunidade = c.nome
WHERE
    (d.data_fim IS NULL OR d.data_fim > SYSDATE);

-- ========================= PLANETA =========================
CREATE OR REPLACE VIEW view_relatorio_planeta AS
SELECT 
    p.id_astro AS planeta, 
    d.nacao,
    c.especie, 
    c.nome AS comunidade, 
    c.qtd_habitantes,
    h.data_ini, 
    h.data_fim
FROM 
    planeta p
    JOIN habitacao h ON p.id_astro = h.planeta
    JOIN comunidade c ON h.especie = c.especie AND h.comunidade = c.nome
    JOIN dominancia d ON p.id_astro = d.planeta
WHERE
    (d.data_fim IS NULL OR d.data_fim > SYSDATE);

