---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------

-- RELATÓRIOS

-- 1)

-- a. Informações sobre comunidades da própria facção: um líder de facção está
-- interessado em recuperar informações sobre as comunidades participantes,
-- facilitando a tomada de decisões de expansão da própria facção.

-- i. Comunidades podem ser agrupadas por nação, espécie, planeta, e/ou sistema.

-- CONSULTA
-- Visualizacao de informacoes

SELECT * FROM FACCAO;



CREATE OR REPLACE PROCEDURE relatorio_comunidades(
    p_faccao IN faccao.nome%TYPE,
    p_cursor OUT SYS_REFCURSOR
) AS
    v_count NUMBER;
    e_faccao_nao_pertencente EXCEPTION;
    pragma exception_init(e_faccao_nao_pertencente, -20002);
BEGIN
    SELECT COUNT(*) INTO v_count 
    FROM view_gerenciamento_comunidades 
    WHERE faccao = p_faccao;

    IF v_count = 0 THEN
        RAISE e_faccao_nao_pertencente;
    ELSE
        OPEN p_cursor FOR
        SELECT nacao, planeta, sistema, especie, comunidade, qtd_habitantes, status_credenciamento
        FROM view_gerenciamento_comunidades 
        WHERE faccao = p_faccao;
    END IF;
EXCEPTION
    WHEN e_faccao_nao_pertencente THEN
        RAISE_APPLICATION_ERROR(-20002, 'A facção não corresponde ao líder informado.');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20000, 'Erro ao visualizar informações: ' || SQLERRM);
END relatorio_comunidades;





-- TESTE
-- Programa principal
DECLARE
    l_cursor SYS_REFCURSOR;
    l_nacao view_gerenciamento_comunidades.nacao%TYPE;
    l_planeta view_gerenciamento_comunidades.planeta%TYPE;
   	l_sistema view_gerenciamento_comunidades.sistema%TYPE;
    l_especie view_gerenciamento_comunidades.especie%TYPE;
    l_comunidade view_gerenciamento_comunidades.comunidade%TYPE;
    l_qtd_habitantes view_gerenciamento_comunidades.qtd_habitantes%TYPE;
    l_status view_gerenciamento_comunidades.status_credenciamento%TYPE;
    p_faccao faccao.nome%TYPE := 'CENTRAL_DO_MEDO'; -- Replace 'Nome_da_Faccao' with the actual facção name
BEGIN
    -- Chamar a procedure
    relatorio_comunidades(p_faccao, l_cursor);
    
   -- Process the data (e.g., DBMS_OUTPUT.PUT_LINE)
        DBMS_OUTPUT.PUT_LINE('GERENCIAMENTO DE COMUNIDADES PERTENCENTES À FACÇÃO ' || p_faccao);
        -- Linha de separação
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 13, '-'));
        
        -- Cabeçalho
        DBMS_OUTPUT.PUT_LINE(RPAD('|', 2) || RPAD('Nação', 18) ||
                             RPAD('|', 2) || RPAD('Planeta', 18) ||
                             RPAD('|', 2) || RPAD('Sistema'), 18 ||
                             RPAD('|', 2) || RPAD('Espécie', 18) ||
                             RPAD('|', 2) || RPAD('Comunidade', 18) ||
                             RPAD('|', 2) || RPAD('Qtd_Habitantes', 18) ||
                             RPAD('|', 2) || RPAD('Status', 18) || '|');
        
        -- Linha de separação
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 13, '-'));
        
    -- Fetch the data
    LOOP
        FETCH l_cursor INTO l_nacao, l_planeta, l_sistema, l_especie, l_comunidade, l_qtd_habitantes, l_status;
        EXIT WHEN l_cursor%NOTFOUND;

        
        -- Dados
        DBMS_OUTPUT.PUT_LINE(
            RPAD('|', 2) || RPAD(NVL(l_nacao, ' '), 18) || 
            RPAD('|', 2) || RPAD(NVL(l_planeta, ' '), 18) ||
            RPAD('|', 2) || RPAD(NVL(l_sistema, ' '), 18) ||
            RPAD('|', 2) || RPAD(NVL(l_especie, ' '), 18) || 
            RPAD('|', 2) || RPAD(NVL(l_comunidade, ' '), 18) ||
            RPAD('|', 2) || RPAD(NVL(TO_CHAR(l_qtd_habitantes), '0'), 18) ||
            RPAD('|', 2) || RPAD(NVL(l_status, ' '), 18) || '|'
        );

        -- Linha de separação final
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 18, '-') || RPAD('-', 13, '-'));
	END LOOP;
    
    -- Fechar o cursor
    CLOSE l_cursor;
END;




SELECT * FROM user_errors;

