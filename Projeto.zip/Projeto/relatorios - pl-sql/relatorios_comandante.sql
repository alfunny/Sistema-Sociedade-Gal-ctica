-- procedure relatorio listar_dominancia_planetas ===========================================================================================
CREATE OR REPLACE PROCEDURE listar_dominancia_planetas(
    p_cpi_lider LIDER.CPI%TYPE,
    p_cursor OUT SYS_REFCURSOR
) IS
    v_nacao_comandante LIDER.NACAO%TYPE;
BEGIN
    -- Verifica o cargo do líder
    v_nacao_comandante := verificar_cargo(p_cpi_lider);

    IF v_nacao_comandante IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'O CPI fornecido não pertence a um comandante.');
    END IF;

    OPEN p_cursor FOR
        SELECT PLANETA, NACAO, DATA_INI, DATA_FIM
        FROM DOMINANCIA
        WHERE DATA_FIM IS NULL OR DATA_FIM > SYSDATE
        UNION
        SELECT PLANETA, NACAO, DATA_INI, DATA_FIM
        FROM DOMINANCIA
        WHERE DATA_FIM < SYSDATE;
END listar_dominancia_planetas;

SELECT * FROM user_errors;