SELECT * FROM user_errors;
-- TESTE
-- ========================= SISTEMA =========================   
DECLARE
    v_cpi_lider lider.cpi%TYPE := '000.000.000-11';
    v_data_ini DATE := TO_DATE('1900-01-01', 'YYYY-MM-DD');
    v_data_fim DATE := TO_DATE('2023-12-31', 'YYYY-MM-DD');
    v_out_cursor SYS_REFCURSOR;
    v_sistema sistema.nome%TYPE;
    v_estrela estrela.id_estrela%TYPE;
    v_planeta planeta.id_astro%TYPE;
    v_especie especie.nome%TYPE;
    v_comunidade comunidade.nome%TYPE;
    v_data_ini_result DATE;
    v_data_fim_result DATE;
    v_qtd_habitantes NUMBER;
    v_total_habitantes_planeta NUMBER;
    v_media_habitantes_planeta NUMBER;
    v_total_habitantes_ini NUMBER;
    v_total_habitantes_fim NUMBER;
BEGIN
    pacote_relatorio_oficial.relatorio_oficial_sistema(v_cpi_lider, v_data_ini, v_data_fim, v_out_cursor);

    -- Loop para obter e exibir os resultados
    LOOP
        FETCH v_out_cursor INTO 
            v_sistema, 
            v_estrela, 
            v_planeta, 
            v_especie, 
            v_comunidade, 
            v_data_ini_result, 
            v_data_fim_result, 
            v_qtd_habitantes, 
            v_total_habitantes_planeta, 
            v_media_habitantes_planeta, 
            v_total_habitantes_ini, 
            v_total_habitantes_fim;
        EXIT WHEN v_out_cursor%NOTFOUND;

        -- Imprimir os resultados
        DBMS_OUTPUT.PUT_LINE('Sistema: ' || v_sistema);
        DBMS_OUTPUT.PUT_LINE('Estrela: ' || v_estrela);
        DBMS_OUTPUT.PUT_LINE('Planeta: ' || v_planeta);
        DBMS_OUTPUT.PUT_LINE('Espécie: ' || v_especie);
        DBMS_OUTPUT.PUT_LINE('Comunidade: ' || v_comunidade);
        DBMS_OUTPUT.PUT_LINE('Data de Início: ' || TO_CHAR(v_data_ini_result, 'YYYY-MM-DD'));
        DBMS_OUTPUT.PUT_LINE('Data de Fim: ' || COALESCE(TO_CHAR(v_data_fim_result, 'YYYY-MM-DD'), 'Atualmente'));
        DBMS_OUTPUT.PUT_LINE('Quantidade de Habitantes: ' || v_qtd_habitantes);
        DBMS_OUTPUT.PUT_LINE('Total de Habitantes no Planeta: ' || v_total_habitantes_planeta);
        DBMS_OUTPUT.PUT_LINE('Média de Habitantes por Comunidade no Planeta: ' || ROUND(v_media_habitantes_planeta, 2));
        DBMS_OUTPUT.PUT_LINE('Quantidade de habitantes em ' || TO_CHAR(v_data_ini, 'YYYY-MM-DD') || ': ' || v_total_habitantes_ini);
        DBMS_OUTPUT.PUT_LINE('Quantidade de habitantes em ' || TO_CHAR(v_data_fim, 'YYYY-MM-DD') || ': ' || v_total_habitantes_fim);
        DBMS_OUTPUT.PUT_LINE('Diferença de Habitantes: ' || (v_total_habitantes_fim - v_total_habitantes_ini));
        DBMS_OUTPUT.PUT_LINE('Percentual de Crescimento/Diminuição: ' || ROUND((v_total_habitantes_fim - v_total_habitantes_ini) * 100 / v_total_habitantes_ini, 2) || '%');
        DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------');
    END LOOP;

    CLOSE v_out_cursor;
END;



-- ========================= FACCAO =========================   
DECLARE
    v_cpi_lider lider.cpi%TYPE := '000.000.000-10';
    v_data_ini DATE := TO_DATE('1900-01-01', 'YYYY-MM-DD');
    v_data_fim DATE := TO_DATE('2023-12-31', 'YYYY-MM-DD');
    v_out_cursor SYS_REFCURSOR;
    v_faccao faccao.nome%TYPE;
    v_lider lider.cpi%TYPE;
    v_planeta planeta.id_astro%TYPE;
    v_especie especie.nome%TYPE;
    v_comunidade comunidade.nome%TYPE;
    v_data_ini_result DATE;
    v_data_fim_result DATE;
    v_qtd_habitantes NUMBER;
    v_total_habitantes_planeta NUMBER;
    v_media_habitantes_planeta NUMBER;
    v_total_habitantes_ini NUMBER;
    v_total_habitantes_fim NUMBER;
BEGIN
    pacote_relatorio_oficial.relatorio_oficial_faccao(v_cpi_lider, v_data_ini, v_data_fim, v_out_cursor);

    -- Loop para obter e exibir os resultados
    LOOP
        FETCH v_out_cursor INTO 
            v_faccao, 
            v_lider, 
            v_planeta, 
            v_especie, 
            v_comunidade, 
            v_data_ini_result, 
            v_data_fim_result, 
            v_qtd_habitantes, 
            v_total_habitantes_planeta, 
            v_media_habitantes_planeta, 
            v_total_habitantes_ini, 
            v_total_habitantes_fim;
        EXIT WHEN v_out_cursor%NOTFOUND;

        -- Imprimir os resultados
        DBMS_OUTPUT.PUT_LINE('Facção: ' || v_faccao);
        DBMS_OUTPUT.PUT_LINE('Líder: ' || v_lider);
        DBMS_OUTPUT.PUT_LINE('Planeta: ' || v_planeta);
        DBMS_OUTPUT.PUT_LINE('Espécie: ' || v_especie);
        DBMS_OUTPUT.PUT_LINE('Comunidade: ' || v_comunidade);
        DBMS_OUTPUT.PUT_LINE('Data de Início: ' || TO_CHAR(v_data_ini_result, 'YYYY-MM-DD'));
        DBMS_OUTPUT.PUT_LINE('Data de Fim: ' || COALESCE(TO_CHAR(v_data_fim_result, 'YYYY-MM-DD'), 'Atualmente'));
        DBMS_OUTPUT.PUT_LINE('Quantidade de Habitantes: ' || v_qtd_habitantes);
        DBMS_OUTPUT.PUT_LINE('Total de Habitantes no Planeta: ' || v_total_habitantes_planeta);
        DBMS_OUTPUT.PUT_LINE('Média de Habitantes por Comunidade no Planeta: ' || ROUND(v_media_habitantes_planeta, 2));
        DBMS_OUTPUT.PUT_LINE('Quantidade de habitantes em ' || TO_CHAR(v_data_ini, 'YYYY-MM-DD') || ': ' || v_total_habitantes_ini);
        DBMS_OUTPUT.PUT_LINE('Quantidade de habitantes em ' || TO_CHAR(v_data_fim, 'YYYY-MM-DD') || ': ' || v_total_habitantes_fim);
        DBMS_OUTPUT.PUT_LINE('Diferença de Habitantes: ' || (v_total_habitantes_fim - v_total_habitantes_ini));
        DBMS_OUTPUT.PUT_LINE('Percentual de Crescimento/Diminuição: ' || ROUND((v_total_habitantes_fim - v_total_habitantes_ini) * 100 / v_total_habitantes_ini, 2) || '%');
        DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------');
    END LOOP;

    CLOSE v_out_cursor;
END;


   
-- TESTE
-- ========================= ESPECIE =========================   
DECLARE
    v_cpi_lider lider.cpi%TYPE := '000.000.000-11';
    v_data_ini DATE := TO_DATE('1900-01-01', 'YYYY-MM-DD');
    v_data_fim DATE := TO_DATE('2023-12-31', 'YYYY-MM-DD');
    v_out_cursor SYS_REFCURSOR;
    v_especie especie.nome%TYPE;
    v_planeta_or planeta.id_astro%TYPE;
    v_planeta planeta.id_astro%TYPE;
    v_comunidade comunidade.nome%TYPE;
    v_data_ini_result DATE;
    v_data_fim_result DATE;
    v_qtd_habitantes NUMBER;
    v_total_habitantes_planeta NUMBER;
    v_media_habitantes_planeta NUMBER;
    v_total_habitantes_ini NUMBER;
    v_total_habitantes_fim NUMBER;
BEGIN
    pacote_relatorio_oficial.relatorio_oficial_especie(v_cpi_lider, v_data_ini, v_data_fim, v_out_cursor);

    -- Loop para obter e exibir os resultados
    LOOP
        FETCH v_out_cursor INTO 
            v_especie, 
            v_planeta_or, 
            v_planeta, 
            v_comunidade, 
            v_data_ini_result, 
            v_data_fim_result, 
            v_qtd_habitantes, 
            v_total_habitantes_planeta, 
            v_media_habitantes_planeta, 
            v_total_habitantes_ini, 
            v_total_habitantes_fim;
        EXIT WHEN v_out_cursor%NOTFOUND;

        -- Imprimir os resultados
        DBMS_OUTPUT.PUT_LINE('Espécie: ' || v_especie);
        DBMS_OUTPUT.PUT_LINE('Planeta de Origem: ' || v_planeta_or);
        DBMS_OUTPUT.PUT_LINE('Planeta: ' || v_planeta);
        DBMS_OUTPUT.PUT_LINE('Comunidade: ' || v_comunidade);
        DBMS_OUTPUT.PUT_LINE('Data de Início: ' || TO_CHAR(v_data_ini_result, 'YYYY-MM-DD'));
        DBMS_OUTPUT.PUT_LINE('Data de Fim: ' || COALESCE(TO_CHAR(v_data_fim_result, 'YYYY-MM-DD'), 'Atualmente'));
        DBMS_OUTPUT.PUT_LINE('Quantidade de Habitantes: ' || v_qtd_habitantes);
        DBMS_OUTPUT.PUT_LINE('Total de Habitantes no Planeta: ' || v_total_habitantes_planeta);
        DBMS_OUTPUT.PUT_LINE('Média de Habitantes por Comunidade no Planeta: ' || ROUND(v_media_habitantes_planeta, 2));
        DBMS_OUTPUT.PUT_LINE('Quantidade de habitantes em ' || TO_CHAR(v_data_ini, 'YYYY-MM-DD') || ': ' || v_total_habitantes_ini);
        DBMS_OUTPUT.PUT_LINE('Quantidade de habitantes em ' || TO_CHAR(v_data_fim, 'YYYY-MM-DD') || ': ' || v_total_habitantes_fim);
        DBMS_OUTPUT.PUT_LINE('Diferença de Habitantes: ' || (v_total_habitantes_fim - v_total_habitantes_ini));
        DBMS_OUTPUT.PUT_LINE('Percentual de Crescimento/Diminuição: ' || ROUND((v_total_habitantes_fim - v_total_habitantes_ini) * 100 / v_total_habitantes_ini, 2) || '%');
        DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------');
    END LOOP;

    CLOSE v_out_cursor;
END;

SELECT * FROM dominancia;
   
-- TESTE
-- ========================= PLANETA =========================   
DECLARE
    v_cpi_lider lider.cpi%TYPE := '000.000.000-11';
    v_data_ini DATE := TO_DATE('1900-01-01', 'YYYY-MM-DD');
    v_data_fim DATE := TO_DATE('2023-12-31', 'YYYY-MM-DD');
    v_out_cursor SYS_REFCURSOR;
    v_planeta planeta.id_astro%TYPE;
    v_nacao nacao.nome%TYPE;
    v_especie especie.nome%TYPE;
    v_comunidade comunidade.nome%TYPE;
    v_data_ini_result DATE;
    v_data_fim_result DATE;
    v_qtd_habitantes NUMBER;
    v_total_habitantes_planeta NUMBER;
    v_media_habitantes_planeta NUMBER;
    v_total_habitantes_ini NUMBER;
    v_total_habitantes_fim NUMBER;
    v_diferenca_habitantes NUMBER;
    v_percentual_crescimento NUMBER;
BEGIN
    pacote_relatorio_oficial.relatorio_oficial_planeta(v_cpi_lider, v_data_ini, v_data_fim, v_out_cursor);

    -- Loop para obter e exibir os resultados
    LOOP
        FETCH v_out_cursor INTO 
            v_planeta, 
            v_nacao, 
            v_especie, 
            v_comunidade, 
            v_data_ini_result, 
            v_data_fim_result, 
            v_qtd_habitantes, 
            v_total_habitantes_planeta, 
            v_media_habitantes_planeta, 
            v_total_habitantes_ini, 
            v_total_habitantes_fim,
            v_diferenca_habitantes,
            v_percentual_crescimento;
        EXIT WHEN v_out_cursor%NOTFOUND;

        -- Imprimir os resultados
        DBMS_OUTPUT.PUT_LINE('Planeta: ' || v_planeta);
        DBMS_OUTPUT.PUT_LINE('Nação: ' || v_nacao);
        DBMS_OUTPUT.PUT_LINE('Espécie: ' || v_especie);
        DBMS_OUTPUT.PUT_LINE('Comunidade: ' || v_comunidade);
        DBMS_OUTPUT.PUT_LINE('Data de Início: ' || TO_CHAR(v_data_ini_result, 'YYYY-MM-DD'));
        DBMS_OUTPUT.PUT_LINE('Data de Fim: ' || COALESCE(TO_CHAR(v_data_fim_result, 'YYYY-MM-DD'), 'Atualmente'));
        DBMS_OUTPUT.PUT_LINE('Quantidade de Habitantes: ' || v_qtd_habitantes);
        DBMS_OUTPUT.PUT_LINE('Total de Habitantes no Planeta: ' || v_total_habitantes_planeta);
        DBMS_OUTPUT.PUT_LINE('Média de Habitantes por Comunidade no Planeta: ' || ROUND(v_media_habitantes_planeta, 2));
        DBMS_OUTPUT.PUT_LINE('Quantidade de habitantes em ' || TO_CHAR(v_data_ini, 'YYYY-MM-DD') || ': ' || v_total_habitantes_ini);
        DBMS_OUTPUT.PUT_LINE('Quantidade de habitantes em ' || TO_CHAR(v_data_fim, 'YYYY-MM-DD') || ': ' || v_total_habitantes_fim);
        DBMS_OUTPUT.PUT_LINE('Diferença de Habitantes: ' || v_diferenca_habitantes);
        DBMS_OUTPUT.PUT_LINE('Percentual de Crescimento/Diminuição: ' || COALESCE(v_percentual_crescimento, 0) || '%');
        DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------');
    END LOOP;

    CLOSE v_out_cursor;
END;


   
   
   
