-- TESTES

-- PROCEDURE ------------------------------------------------------------------------------------------------------------

-- INSERCAO DOS LIDERES EXISTENTES
BEGIN
    inserir_usuario('password1', '222.153.654-43');
    inserir_usuario('password2', '444.153.654-68');
    inserir_usuario('password3', '555.243.611-71');
   	inserir_usuario('password4', '123.456.789-10');
  	inserir_usuario('password5', '987.654.321-20');
	inserir_usuario('password6', '159.753.456-30');
	inserir_usuario('password7', '753.159.654-40');
	inserir_usuario('password8', '124.578.356-58');
	inserir_usuario('password9', '111.159.654-40');
	inserir_usuario('password10', '123.456.789-00');
	inserir_usuario('password11', '125.635.459-87');
	inserir_usuario('password12', '151.262.353-57');
	inserir_usuario('password13', '242.353.575-85');
	inserir_usuario('password14', '151.252.656-86');
	inserir_usuario('password15', '159.159.357-58');
	inserir_usuario('password16', '666.333.000-69');
   	
END;


SELECT * FROM USERS;


--	USER_ID	|	PASSWORD							|	ID_LIDER
----------------------------------------------------------------------
--	1		|	7C6A180B36896A0A8C02787EEAFB0E4C	|	222.153.654-43
--  2		| 	6CB75F652A9B52798EB6CF2201057C73	|	444.153.654-68
--  3		| 	819B0643D6B89DC9B579FDFC9094F28E	|	555.243.611-71
--  4		|	34CC93ECE0BA9E3F6F235D4AF979B16C	|	123.456.789-10
--  5		|	DB0EDD04AAAC4506F7EDAB03AC855D56	|	987.654.321-20
--  6		|	218DD27AEBECCECAE69AD8408D9A36BF	|	159.753.456-30
--  7		|	00CDB7BB942CF6B290CEB97D6ACA64A3	|	753.159.654-40
--  8		|	B25EF06BE3B6948C0BC431DA46C2C738	|	124.578.356-58
--  9		|	5D69DD95AC183C9643780ED7027D128A	|	111.159.654-40
-- 10		|	87E897E3B54A405DA144968B2CA19B45	|	123.456.789-00
-- 11		|	1E5C2776CF544E213C3D279C40719643	|	125.635.459-87
-- 12		|	C24A542F884E144451F9063B79E7994E	|	151.262.353-57
-- 13		|	EE684912C7E588D03CCB40F17ED080C9	|	242.353.575-85
-- 14		|	8EE736784CE419BD16554ED5677FF35B	|	151.252.656-86
-- 15		|	9141FEA0574F83E190AB7479D516630D	|	159.159.357-58
-- 16		|	2B40AAA979727C43411C305540BBED50	|	666.333.000-69



-- INSERCAO INCORRETA

INSERT INTO lider(cpi, nome, cargo, nacao, especie)
	values('888.111.222-33', 'lider_user_2', 'CIENTISTA', 'Enim earum id.', 'Non eos qui');

BEGIN
	inserir_usuario('', '888.111.222-33');
END;

-- Erro SQL [20007] [72000]: ORA-20007: Senha não informada!

BEGIN
	inserir_usuario(null, '888.111.222-33');
END;
-- Erro SQL [20007] [72000]: ORA-20007: Senha não informada!


-- TRIGGER ------------------------------------------------------------------------------------------------------------

-- INSERT LIDER
INSERT INTO lider(cpi, nome, cargo, nacao, especie)
	values('000.111.222-33', 'lider_user_1', 'OFICIAL', 'Enim earum id.', 'Non eos qui');

SELECT * FROM lider;
-- 	CPI				| 	NOME			| 	CARGO		|	NACAO			| 	ESPECIE
-----------------------------------------------------------------------------------------------
--	222.153.654-43	|	pe_sujo			|	OFICIAL   	|	Quis aut eum.	|	Eos ex amet
--	444.153.654-68	|	cai_duro		|	COMANDANTE	|	Deserunt vero.	|	Nisi id eum
--	555.243.611-71	|	ze				|	CIENTISTA 	|	Deserunt vero.	|	Nisi id eum
--	123.456.789-10	|	BAGUNCINHA		|	COMANDANTE	|	Facilis illo.	|	Odio ex in
--	987.654.321-20	|	ZE_DA_MANGA		|	OFICIAL   	|	Non eius in.	|	In dicta
--	159.753.456-30	|	ROGERINHO		|	CIENTISTA 	|	Id ex soluta.	|	Ut culpa
--	753.159.654-40	|	BIBI_PERIGOSA	|	OFICIAL   	|	Natus a.		|	Amet id
--	124.578.356-58	|	JESUS			|	OFICIAL   	|	Eum in ut.		|	Sed eaque amet
--	000.111.222-33	|	lider_user_1	|	OFICIAL   	|	Enim earum id.	|	Non eos qui			<<<== INSERCAO
--	111.159.654-40	|	PERIGOSA		|	OFICIAL   	|	Quis aut eum.	|	Eos ex amet
--	123.456.789-00	|	Poderoso_Chefao	|	COMANDANTE	|	Deserunt vero.	|	Officiis totam
--	125.635.459-87	|	JOAO_DO_GAS		|	COMANDANTE	|	Ex omnis.		|	Non eos qui
--	151.262.353-57	|	Marcola			|	COMANDANTE	|	Enim earum id.	|	Animi esse
--	242.353.575-85	|	Nem				|	OFICIAL   	|	Ullam neque.	|	Et ab fugit
--	151.252.656-86	|	LIDER_11		|	OFICIAL   	|	Commodi illum.	|	Quam nam id
--	159.159.357-58	|	ze_mane			|	OFICIAL   	|	Quis aut eum.	|	Eos ex amet
--	666.333.000-69	|	cai_duro		|	COMANDANTE	|	Quis aut eum.	|	Eos ex amet


SELECT * FROM users;
--	USER_ID	|	PASSWORD							|	ID_LIDER
----------------------------------------------------------------------
--	1		|	7C6A180B36896A0A8C02787EEAFB0E4C	|	222.153.654-43
--  2		| 	6CB75F652A9B52798EB6CF2201057C73	|	444.153.654-68
--  3		| 	819B0643D6B89DC9B579FDFC9094F28E	|	555.243.611-71
--  4		|	34CC93ECE0BA9E3F6F235D4AF979B16C	|	123.456.789-10
--  5		|	DB0EDD04AAAC4506F7EDAB03AC855D56	|	987.654.321-20
--  6		|	218DD27AEBECCECAE69AD8408D9A36BF	|	159.753.456-30
--  7		|	00CDB7BB942CF6B290CEB97D6ACA64A3	|	753.159.654-40
--  8		|	B25EF06BE3B6948C0BC431DA46C2C738	|	124.578.356-58
--  9		|	5D69DD95AC183C9643780ED7027D128A	|	111.159.654-40
-- 10		|	87E897E3B54A405DA144968B2CA19B45	|	123.456.789-00
-- 11		|	1E5C2776CF544E213C3D279C40719643	|	125.635.459-87
-- 12		|	C24A542F884E144451F9063B79E7994E	|	151.262.353-57
-- 13		|	EE684912C7E588D03CCB40F17ED080C9	|	242.353.575-85
-- 14		|	8EE736784CE419BD16554ED5677FF35B	|	151.252.656-86
-- 15		|	9141FEA0574F83E190AB7479D516630D	|	159.159.357-58
-- 16		|	2B40AAA979727C43411C305540BBED50	|	666.333.000-69
-- 17		|	0D63031864EAEEAB8BAF66BEE4E9C3B9	|	000.111.222-33			<<<== INSERCAO





-- testando update, comportamento padrão, ok
UPDATE LIDER SET cpi = '001.111.222-33' WHERE cpi = '000.111.222-33';
--Erro SQL [2292] [23000]: ORA-02292: restrição de integridade (A10727952.FK_IDLIDER) violada - registro filho localizado



SELECT * FROM tab;

SELECT * FROM auth_user;

