------------------------------------------------------------------------------------------------------------------------------------------------------
-- PROGRAMAS PRINCIPAIS - TESTES

-- a.
--i. Alterar nome da facção
-- => implica em alterações nas tabelas: faccao, nacao_faccao, e na view_gerenciamento_comunidades
DECLARE
    v_faccao faccao.nome%TYPE;
    v_novo_nome faccao.nome%TYPE;

BEGIN

    -- Exemplo 1: sucesso
    v_faccao := 'FACCAO_11';
    v_novo_nome := 'FACCAO_1';
    pacote_func_lider.alterar_nome_faccao(v_faccao, v_novo_nome);

    -- Exemplo 2: faccao não encontrada
--     v_faccao := 'fac1';
--     v_novo_nome := 'sk8';
--     pacote_func_lider.alterar_nome_faccao(v_faccao, v_novo_nome);
	-- Erro SQL [20001] [72000]: ORA-20001: Erro: Facção não encontrada.

    
    -- caso em que o nome indicado já existe - chave primária
--   	v_faccao := 'FACCAO_1';
--	v_novo_nome := 'CENTRAL_DO_MEDO';
--	pacote_func_lider.alterar_nome_faccao(v_faccao, v_novo_nome);
	
END;


SELECT * FROM FACCAO;
--|	FACCAO_NOME		|	LIDER				|	IDEOLOGIA			|	QTD_NACOES
-----------------------------------------------------------------------------------
--|	faccao_commit	|	151.262.353-57		|	TOTALITARIA			|	3
--|	CENTRAL_DO_MEDO	|	123.456.789-10		|	TRADICIONALISTA		|	3
--|	FACCAO_CENTRAL	|	987.654.321-20		|	PROGRESSITA			|	2
--|	FACCAO_1		|	123.456.789-00		|	PROGRESSITA			|	2		<<<== alteracao
--|	SAMARA_MORGAN	|	753.159.654-40		|	TOTALITARIA			|	3
--|	INVOCACAO_D_MAL	|	124.578.356-58		|	PROGRESSITA			|	1
--|	DEUS_E_AMOR		|	111.159.654-40		|	TOTALITARIA			|	2
--|	comandovermelho	|	555.243.611-71		|	[NULL]				|	[NULL]	
--|	FACCAO_22		|	151.252.656-86		|	PROGRESSITA			|	2		
--|	horda			|	666.333.000-69		|	TRADICIONALISTA		|	3
--|	Holidays		|	159.753.456-30		|	TRADICIONALISTA		|	1
--|	hora_do_horror	|	222.153.654-43		|	[NULL]				|	[NULL]
--|	pcc				|	444.153.654-68		|	[NULL]				|	[NULL]


SELECT * FROM NACAO_FACCAO;
--|	NACAO			|	FACCAO
------------------------------------
--|	At natus.		|	CENTRAL_DO_MEDO
--|	Commodi illum.	|	CENTRAL_DO_MEDO
--|	Commodi illum.	|	FACCAO_22			
--|	Deserunt vero.	|	CENTRAL_DO_MEDO
--|	Deserunt vero.	|	FACCAO_1			<<<== alteracao
--|	Eum in ut.		|	CENTRAL_DO_MEDO
--|	Id ex soluta.	|	Holidays
--|	Nam ut a.		|	CENTRAL_DO_MEDO
--|	Nemo nobis.		|	FACCAO_CENTRAL
--|	Non eius in.	|	FACCAO_CENTRAL
--|	Non soluta sit.	|	CENTRAL_DO_MEDO


SELECT * FROM VIEW_GERENCIAMENTO_COMUNIDADES;
--|	FACCAO			|	NACAO			|	PLANETA			|	SISTEMA		|	ESPECIE			|	COMUNIDADE	|	QTD_HABITANTES	|	STATUS_CREDENCIAMENTO
--------------------------------------------------------------------------------------------------------------------------------------------------------------
--|	CENTRAL_DO_MEDO	|	Commodi illum.	|	Nostrum ad ea.	|	[NULL]		|	Rerum nesciunt	|	com8		|	500				|	Credenciada
--|	FACCAO_22		|	Commodi illum.	|	Nostrum ad ea.	|	[NULL]		|	Rerum nesciunt	|	com8		|	500				|	Não Credenciada		
--|	CENTRAL_DO_MEDO	|	Deserunt vero.	|	In iure.		|	[NULL]		|	Et sunt rerum	|	com7		|	507				|	Credenciada
--|	FACCAO_1		|	Deserunt vero.	|	In iure.		|	[NULL]		|	Et sunt rerum	|	com7		|	507				|	Não Credenciada	<<<== alteracao
--|	CENTRAL_DO_MEDO	|	Eum in ut.		|	Tenetur et.		|	[NULL]		|	Tempore ex hic	|	com10		|	5454			|	Credenciada
--|	CENTRAL_DO_MEDO	|	Nam ut a.		|	Est a.			|	SOLAR		|	Quam nam id		|	com9		|	1245			|	Credenciada


SELECT * FROM PARTICIPA;
--|	FACCAO			|	NACAO			|	COMUNIDADE
-------------------------------------------------------
--|	CENTRAL_DO_MEDO	|	Et sunt rerum	|	com7
--|	CENTRAL_DO_MEDO	|	Quam nam id		|	com9
--|	CENTRAL_DO_MEDO	|	Rerum nesciunt	|	com8
--|	CENTRAL_DO_MEDO	|	Tempore ex hic	|	com10
--|	FACCAO_1		|	Nisi id eum		|	com5	<<<== alteracao
--|	FACCAO_CENTRAL	|	Non eos qui		|	com1


------------------------------------------------------------------------------------------------------------------------------------------------------
-- TESTE TRIGGER FACCAO

INSERT INTO LIDER(CPI, NOME, CARGO, NACAO, ESPECIE) values('151.252.656-86', 'LIDER_11', 'OFICIAL','Commodi illum.', 'Quam nam id');

INSERT INTO FACCAO(NOME, LIDER, IDEOLOGIA, QTD_NACOES) values('FACCAO_22', '151.252.656-86', 'PROGRESSITA', 2);


-- RESULTADOS - FACCAO_22

SELECT * FROM FACCAO;
--|	FACCAO_NOME		|	LIDER				|	IDEOLOGIA			|	QTD_NACOES
-----------------------------------------------------------------------------------
--|	faccao_commit	|	151.262.353-57		|	TOTALITARIA			|	3
--|	CENTRAL_DO_MEDO	|	123.456.789-10		|	TRADICIONALISTA		|	3
--|	FACCAO_CENTRAL	|	987.654.321-20		|	PROGRESSITA			|	2
--|	FACCAO_11		|	123.456.789-00		|	PROGRESSITA			|	2
--|	SAMARA_MORGAN	|	753.159.654-40		|	TOTALITARIA			|	3
--|	INVOCACAO_D_MAL	|	124.578.356-58		|	PROGRESSITA			|	1
--|	DEUS_E_AMOR		|	111.159.654-40		|	TOTALITARIA			|	2
--|	comandovermelho	|	555.243.611-71		|	[NULL]				|	[NULL]	
--|	FACCAO_22		|	151.252.656-86		|	PROGRESSITA			|	2		<<<== alteracao
--|	horda			|	666.333.000-69		|	TRADICIONALISTA		|	3
--|	Holidays		|	159.753.456-30		|	TRADICIONALISTA		|	1
--|	hora_do_horror	|	222.153.654-43		|	[NULL]				|	[NULL]
--|	pcc				|	444.153.654-68		|	[NULL]				|	[NULL]


SELECT * FROM NACAO_FACCAO;
--|	NACAO			|	FACCAO
------------------------------------
--|	At natus.		|	CENTRAL_DO_MEDO
--|	Commodi illum.	|	CENTRAL_DO_MEDO
--|	Commodi illum.	|	FACCAO_22			<<<== alteracao
--|	Deserunt vero.	|	CENTRAL_DO_MEDO
--|	Deserunt vero.	|	FACCAO_11
--|	Eum in ut.		|	CENTRAL_DO_MEDO
--|	Id ex soluta.	|	Holidays
--|	Nam ut a.		|	CENTRAL_DO_MEDO
--|	Nemo nobis.		|	FACCAO_CENTRAL
--|	Non eius in.	|	FACCAO_CENTRAL
--|	Non soluta sit.	|	CENTRAL_DO_MEDO


SELECT * FROM VIEW_GERENCIAMENTO_COMUNIDADES;
--|	FACCAO			|	NACAO			|	PLANETA			|	SISTEMA		|	ESPECIE			|	COMUNIDADE		|	QTD_HABITANTES	|	STATUS_CREDENCIAMENTO
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--|	CENTRAL_DO_MEDO	|	Commodi illum.	|	Nostrum ad ea.	|	[NULL]		|	Rerum nesciunt	|	com8			|	500				|	Credenciada
--|	FACCAO_22		|	Commodi illum.	|	Nostrum ad ea.	|	[NULL]		|	Rerum nesciunt	|	com8			|	500				|	Não Credenciada		<<<== alteracao
--|	CENTRAL_DO_MEDO	|	Deserunt vero.	|	In iure.		|	[NULL]		|	Et sunt rerum	|	com7			|	507				|	Credenciada
--|	FACCAO_11		|	Deserunt vero.	|	In iure.		|	[NULL]		|	Et sunt rerum	|	com7			|	507				|	Não Credenciada
--|	CENTRAL_DO_MEDO	|	Eum in ut.		|	Tenetur et.		|	[NULL]		|	Tempore ex hic	|	com10			|	5454			|	Credenciada
--|	CENTRAL_DO_MEDO	|	Nam ut a.		|	Est a.			|	SOLAR		|	Quam nam id		|	com9			|	1245			|	Credenciada


-- nao ha alteracao em participa, pois o lider deve credenciar a faccao !!!!!!!!!!!!!!!!
SELECT * FROM PARTICIPA;
--|	FACCAO			|	NACAO			|	COMUNIDADE
-------------------------------------------------------
--|	CENTRAL_DO_MEDO	|	Et sunt rerum	|	com7
--|	CENTRAL_DO_MEDO	|	Quam nam id		|	com9
--|	CENTRAL_DO_MEDO	|	Rerum nesciunt	|	com8
--|	CENTRAL_DO_MEDO	|	Tempore ex hic	|	com10
--|	FACCAO_11		|	Nisi id eum		|	com5
--|	FACCAO_CENTRAL	|	Non eos qui		|	com1



-- apos credenciamento da faccao em Participa !!!!!!!!!!!!!!!
SELECT * FROM VIEW_GERENCIAMENTO_COMUNIDADES;
--|	FACCAO			|	NACAO			|	PLANETA			|	SISTEMA		|	ESPECIE			|	COMUNIDADE		|	QTD_HABITANTES	|	STATUS_CREDENCIAMENTO
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--|	CENTRAL_DO_MEDO	|	Commodi illum.	|	Nostrum ad ea.	|	[NULL]		|	Rerum nesciunt	|	com8			|	500				|	Credenciada
--|	FACCAO_22		|	Commodi illum.	|	Nostrum ad ea.	|	[NULL]		|	Rerum nesciunt	|	com8			|	500				|	Credenciada		<<<== alteracao
--|	CENTRAL_DO_MEDO	|	Deserunt vero.	|	In iure.		|	[NULL]		|	Et sunt rerum	|	com7			|	507				|	Credenciada
--|	FACCAO_11		|	Deserunt vero.	|	In iure.		|	[NULL]		|	Et sunt rerum	|	com7			|	507				|	Não Credenciada
--|	CENTRAL_DO_MEDO	|	Eum in ut.		|	Tenetur et.		|	[NULL]		|	Tempore ex hic	|	com10			|	5454			|	Credenciada
--|	CENTRAL_DO_MEDO	|	Nam ut a.		|	Est a.			|	SOLAR		|	Quam nam id		|	com9			|	1245			|	Credenciada


-----------------------------------------------------------------------------------------------------------------------------------------------------

-- TESTE CREDENCIAMENTO FACCAO

--iii. Credenciar comunidades novas (Participa), que habitem planetas dominados por nações onde a facção está presente/credenciada
-- => implica em alterações na tabela participa
DECLARE
	v_faccao faccao.nome%TYPE;
	v_count integer;

BEGIN
	-- caso de sucesso	
	v_faccao := 'CENTRAL_DO_MEDO';

	-- caso de falha
--	v_faccao := '1234';
	
	-- Verificar se a facção existe
    SELECT COUNT(*) INTO v_count FROM faccao WHERE nome = v_faccao;

    IF v_count > 0 THEN
        pacote_func_lider.inserir_view_ger_comunidades(v_faccao);
    ELSE
        raise no_data_found;
    END IF;
   		
EXCEPTION
	WHEN no_data_found THEN
		dbms_output.put_line('Facção inexistente!');
    WHEN OTHERS THEN
        ROLLBACK;
        raise_application_error(-20000, 'Erro: ' || SQLERRM);   
END;


SELECT * FROM PARTICIPA;
--| FACCAO			|	ESPECIE			|	COMUNIDADE
-------------------------------------------------------
--|	CENTRAL_DO_MEDO	|	Et sunt rerum	|	com7
--|	CENTRAL_DO_MEDO	|	Quam nam id		|	com9
--|	CENTRAL_DO_MEDO	|	Rerum nesciunt	|	com8
--|	CENTRAL_DO_MEDO	|	Tempore ex hic	|	com10
--|	FACCAO_11		|	Nisi id eum		|	com5
--|	FACCAO_22		|	Rerum nesciunt	|	com8	<<<== alteracao
--|	FACCAO_CENTRAL	|	Non eos qui		|	com1

DELETE FROM participa WHERE faccao = 'CENTRAL_DO_MEDO';

SELECT * FROM PARTICIPA;
SELECT * FROM nacao_faccao;

SELECT * FROM VIEW_GERENCIAMENTO_COMUNIDADES;



------------------------------------------------------------------------------------------------------------------------------------------------------


-- TESTE REMOVER FACCAO DE NACAO

--b. Remover facção de Nação (NacaoFacao)
-- => implica em alterações nas tabelas: nacao_faccao, participa e na view_gerenciamento_comunidades

DECLARE
    v_faccao faccao.nome%TYPE;
    v_nacao nacao.nome%TYPE;
BEGIN
    v_faccao := 'FACCAO_22';
    v_nacao := 'Commodi illum.';
    pacote_func_lider.remover_faccao(v_faccao, v_nacao);
END;


SELECT * FROM FACCAO;
--|	FACCAO_NOME		|	LIDER				|	IDEOLOGIA			|	QTD_NACOES
-----------------------------------------------------------------------------------
--|	faccao_commit	|	151.262.353-57		|	TOTALITARIA			|	3
--|	CENTRAL_DO_MEDO	|	123.456.789-10		|	TRADICIONALISTA		|	3
--|	FACCAO_CENTRAL	|	987.654.321-20		|	PROGRESSITA			|	2
--|	FACCAO_11		|	123.456.789-00		|	PROGRESSITA			|	2
--|	SAMARA_MORGAN	|	753.159.654-40		|	TOTALITARIA			|	3
--|	INVOCACAO_D_MAL	|	124.578.356-58		|	PROGRESSITA			|	1
--|	DEUS_E_AMOR		|	111.159.654-40		|	TOTALITARIA			|	2
--|	comandovermelho	|	555.243.611-71		|	[NULL]				|	[NULL]	
--|	FACCAO_22		|	151.252.656-86		|	PROGRESSITA			|	2		<<<== faccao
--|	horda			|	666.333.000-69		|	TRADICIONALISTA		|	3
--|	Holidays		|	159.753.456-30		|	TRADICIONALISTA		|	1
--|	hora_do_horror	|	222.153.654-43		|	[NULL]				|	[NULL]
--|	pcc				|	444.153.654-68		|	[NULL]				|	[NULL]


SELECT * FROM NACAO_FACCAO;				-- exclusao realizada
--|	NACAO			|	FACCAO
------------------------------------
--|	At natus.		|	CENTRAL_DO_MEDO
--|	Commodi illum.	|	CENTRAL_DO_MEDO
--|	Deserunt vero.	|	CENTRAL_DO_MEDO
--|	Deserunt vero.	|	FACCAO_1
--|	Eum in ut.		|	CENTRAL_DO_MEDO
--|	Id ex soluta.	|	Holidays
--|	Nam ut a.		|	CENTRAL_DO_MEDO
--|	Nemo nobis.		|	FACCAO_CENTRAL
--|	Non eius in.	|	FACCAO_CENTRAL
--|	Non soluta sit.	|	CENTRAL_DO_MEDO


SELECT * FROM VIEW_GERENCIAMENTO_COMUNIDADES;		-- exclusao realizada
--|	FACCAO			|	NACAO			|	PLANETA			|	SISTEMA		|	ESPECIE			|	COMUNIDADE		|	QTD_HABITANTES	|	STATUS_CREDENCIAMENTO
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--|	CENTRAL_DO_MEDO	|	Commodi illum.	|	Nostrum ad ea.	|	[NULL]		|	Rerum nesciunt	|	com8			|	500				|	Credenciada
--|	CENTRAL_DO_MEDO	|	Deserunt vero.	|	In iure.		|	[NULL]		|	Et sunt rerum	|	com7			|	507				|	Credenciada
--|	FACCAO_1		|	Deserunt vero.	|	In iure.		|	[NULL]		|	Et sunt rerum	|	com7			|	507				|	Não Credenciada
--|	CENTRAL_DO_MEDO	|	Eum in ut.		|	Tenetur et.		|	[NULL]		|	Tempore ex hic	|	com10			|	5454			|	Credenciada
--|	CENTRAL_DO_MEDO	|	Nam ut a.		|	Est a.			|	SOLAR		|	Quam nam id		|	com9			|	1245			|	Credenciada



SELECT * FROM PARTICIPA;		-- exclusao realizada
--|	FACCAO			|	NACAO			|	COMUNIDADE
-------------------------------------------------------
--|	CENTRAL_DO_MEDO	|	Et sunt rerum	|	com7
--|	CENTRAL_DO_MEDO	|	Quam nam id		|	com9
--|	CENTRAL_DO_MEDO	|	Rerum nesciunt	|	com8
--|	CENTRAL_DO_MEDO	|	Tempore ex hic	|	com10
--|	FACCAO_1		|	Nisi id eum		|	com5
--|	FACCAO_CENTRAL	|	Non eos qui		|	com1


INSERT INTO NACAO_FACCAO(NACAO, FACCAO) VALUES('Commodi illum.', 'FACCAO_22');


---------------------------------------------------------------------------------------------------------------------------------------------------
--ii. Indicar novo líder (Dica: quando um novo líder assume a facção, o líder anterior deve perder o acesso à funcionalidade)  
-- => implica em alteracoes nas tabelas 
DECLARE
	v_lider_atual lider.cpi%TYPE;
	v_novo_lider lider.cpi%TYPE;
BEGIN
	
	-- Exemplo 1: sucesso
    v_lider_atual := '555.243.611-71';
   	v_novo_lider := '666.333.000-69';
    indicar_lider(v_lider_atual, v_novo_lider);
   
   	-- Exemplo 2: lider não encontrado
   	v_lider_atual := '111.333.222-55';
   	v_novo_lider := '411.333.222-55';
	indicar_lider(v_lider_atual, v_novo_lider);
	
END;



-- INSERT INTO NACAO_FACCAO(NACAO, FACCAO) VALUES('Deserunt vero.', 'TUDO_NOSSO');

INSERT INTO NACAO_FACCAO(FACCAO, NACAO) values('CENTRAL_DO_MEDO', 'At natus.');

SELECT * FROM VIEW_GERENCIAMENTO_COMUNIDADES;

SELECT * FROM PARTICIPA;


-- ALTER PROCEDURE credenciar_comunidades COMPILE;
-- SELECT * FROM user_errors WHERE name = 'CREDENCIAR_COMUNIDADES';

SELECT * FROM USER_ERRORS;
