-- inserts completos
INSERT INTO SISTEMA(ESTRELA, NOME) values('4    Vul', 'SOLAR');
INSERT INTO SISTEMA(ESTRELA, NOME) values('Gl 79', 'SISTEMA1');
INSERT INTO SISTEMA(ESTRELA, NOME) values('34Gam Eri', 'SISTEMA2');
INSERT INTO SISTEMA(ESTRELA, NOME) values('Gl 480', 'SISTEMA1');
INSERT INTO SISTEMA(ESTRELA, NOME) values('46Rho3Ari', 'SISTEMA3');
INSERT INTO SISTEMA(ESTRELA, NOME) values('GJ 3466A', 'SISTEMA4');
INSERT INTO SISTEMA(ESTRELA, NOME) values('46Ups Sgr', 'SISTEMA5');

-- sistema com nomes 'null' podem dar problema nos relatórios, tem que tratar
INSERT INTO SISTEMA(ESTRELA, NOME) values('Gl 834B', null);