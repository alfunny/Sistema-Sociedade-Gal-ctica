-- ========================= VIEW GERENCIAMENTO COMUNIDADES =========================
-- criacao de uma view para que possam ser gerados os relatorios

-- VIEW NAO MATERIALIZAVEL
CREATE OR REPLACE VIEW view_gerenciamento_comunidades AS
SELECT nf.faccao, nf.nacao, d.planeta, s.nome AS sistema, c.especie, c.nome AS comunidade, c.qtd_habitantes,
    CASE
        WHEN p.faccao IS NOT NULL THEN 'Credenciada'
        ELSE 'Não Credenciada'
    END AS status_credenciamento
FROM
    nacao_faccao nf
    JOIN dominancia d ON nf.nacao = d.nacao AND (d.data_fim IS NULL OR d.data_fim > SYSDATE)
    JOIN habitacao h ON d.planeta = h.planeta
    JOIN comunidade c ON h.especie = c.especie AND h.comunidade = c.nome
    LEFT JOIN participa p ON nf.faccao = p.faccao AND c.especie = p.especie AND c.nome = p.comunidade
    LEFT JOIN orbita_planeta op ON d.planeta = op.planeta
    LEFT JOIN sistema s ON op.estrela = s.estrela;
