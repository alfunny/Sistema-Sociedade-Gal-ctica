-- LOGS DE USUARIOS

-- ========================= TABELA =========================

-- LOG TABLE
CREATE TABLE log_table(
	user_id NUMBER,
	data_hota timestamp,
	message varchar2(50),

	CONSTRAINT fk_userid FOREIGN KEY(user_id) REFERENCES users(user_id)
);
-- PARA MANTER LOGS DE TRANSACOES NÃO EFETIVADAS - USAR AUTONOMOUS_TRANSACTION


-- ========================= TRIGGER LOGIN/LOGOFF =========================
CREATE OR REPLACE PROCEDURE inserir_log(
    p_user_id IN varchar2,
    p_message IN varchar2
) IS
BEGIN
    INSERT INTO log_table (user_id, data_hota, message)
    VALUES (p_user_id, SYSTIMESTAMP, p_message);
   
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error(-20000, 'Erro: ' || SQLERRM);
END;



