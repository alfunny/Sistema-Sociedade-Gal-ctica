-- LIDER

SELECT * FROM USER_ERRORS;
-- ========================= PACKAGE LIDER =========================
CREATE OR REPLACE PACKAGE pacote_lider AS
   
	PROCEDURE alterar_nome_faccao(p_faccao faccao.nome%TYPE, p_novo_nome faccao.nome%TYPE);
	PROCEDURE indicar_lider(p_lider_atual lider.cpi%TYPE, p_novo_lider lider.cpi%TYPE);
	PROCEDURE inserir_view_ger_comunidades(p_faccao faccao.nome%TYPE);
	PROCEDURE remover_faccao(p_faccao faccao.nome%TYPE, p_nacao nacao.nome%TYPE);

END pacote_lider;


CREATE OR REPLACE PACKAGE BODY pacote_lider AS

	-------------------- ALTERAR NOME DA FACCAO --------------------
	PROCEDURE alterar_nome_faccao (
	    p_faccao IN faccao.nome%TYPE,
	    p_novo_nome IN faccao.nome%TYPE    
	) AS
	
	    e_faccao_nao_encontrada EXCEPTION;
	    pragma exception_init(e_faccao_nao_encontrada, -20001);
	
	BEGIN  
	   
		-- atualizar o nome da faccao na tabela faccao
	    UPDATE faccao SET NOME = p_novo_nome WHERE NOME = p_faccao;
		
	   	-- verificar atualizacao
	    IF SQL%ROWCOUNT = 0 THEN
	        raise e_faccao_nao_encontrada;
	    END IF;
	   
		-- atualizar o nome da faccao na tabela nacao_faccao
	    UPDATE nacao_faccao SET FACCAO = p_novo_nome WHERE FACCAO = p_faccao;
	
	   	-- atualizar o nome da faccao na tabela participa
	   	UPDATE participa SET FACCAO = p_novo_nome WHERE FACCAO = p_faccao;
	   
	    COMMIT;
	  
	    dbms_output.put_line('Nome da facção ' || p_faccao || ' alterado para ' || p_novo_nome);
	
	EXCEPTION
	    WHEN e_faccao_nao_encontrada THEN
	        raise_application_error(-20001, 'Erro: Facção não encontrada.');
	    	ROLLBACK;
		WHEN OTHERS THEN
		    raise_application_error(-20000, 'Erro ao alterar facção: ' || SQLERRM);
		    ROLLBACK;
		    raise;
	
	END alterar_nome_faccao;

	-------------------- INDICAR UM NOVO LIDER PARA A FACCAO --------------------
	PROCEDURE indicar_lider (
		p_lider_atual IN lider.CPI%TYPE,
	    p_novo_lider IN lider.CPI%TYPE
	    ) AS 
	    
	 	e_lider_nao_encontrado EXCEPTION;
	    pragma exception_init(e_lider_nao_encontrado, -20002);
	
	BEGIN
		
		-- atualizar lider na tabela faccao
	    UPDATE faccao SET lider = p_novo_lider WHERE lider = p_lider_atual;
		
	   	-- verificar atualizacao
	    IF SQL%ROWCOUNT = 0 THEN
	        raise e_lider_nao_encontrado;
	    END IF;
	  
--	    dbms_output.put_line('Lider ' || p_novo_lider || ' é o novo responsável pela facção ' || ', indicado pelo antigo líder ' || p_lider_atual);

	EXCEPTION
		WHEN e_lider_nao_encontrado THEN
			raise_application_error(-20002, 'O CPI informado não corresponde a nenhum líder atual.');
			ROLLBACK;
		WHEN OTHERS THEN
		    raise_application_error(-20000, 'Erro: ' || SQLERRM);
		    ROLLBACK;	   
	END indicar_lider;	

	-------------------- CREDENCIAR COMUNIDADES NOVAS --------------------
	-- INSERCAO PELA VIEW
	PROCEDURE inserir_view_ger_comunidades(p_faccao IN faccao.nome%TYPE) AS
	BEGIN
	    FOR r_comunidade IN (
	        SELECT nf.faccao, nf.nacao, d.planeta, c.especie, c.nome AS comunidade
	        FROM
	            nacao_faccao nf
	            JOIN dominancia d ON nf.nacao = d.nacao AND (d.data_fim IS NULL OR d.data_fim > SYSDATE)
	            JOIN habitacao h ON d.planeta = h.planeta
	            JOIN comunidade c ON h.especie = c.especie AND h.comunidade = c.nome
	            LEFT JOIN participa p ON nf.faccao = p.faccao AND c.especie = p.especie AND c.nome = p.comunidade
	        WHERE nf.faccao = p_faccao AND p.faccao IS NULL
	    ) LOOP
	        	INSERT INTO view_gerenciamento_comunidades (faccao, nacao, planeta, especie, comunidade)
	        		VALUES (r_comunidade.faccao, r_comunidade.nacao, r_comunidade.planeta, r_comunidade.especie, r_comunidade.comunidade);
	    	END LOOP;
	        
	        COMMIT;
	        
	        dbms_output.put_line('Comunidades inseridas com sucesso!');
	   
	EXCEPTION
	    WHEN OTHERS THEN
	        ROLLBACK;
	        raise_application_error(-20000, 'Erro: ' || SQLERRM);
	END inserir_view_ger_comunidades;

	-------------------- REMOVER FACCAO --------------------
	PROCEDURE remover_faccao (
	    p_faccao IN faccao.nome%TYPE,
	    p_nacao IN nacao.nome%TYPE
	) AS
	
	    e_faccao_nao_encontrada EXCEPTION;
	    pragma exception_init(e_faccao_nao_encontrada, -20001);
	
	BEGIN
	        
	    DELETE FROM nacao_faccao WHERE nacao = p_nacao AND faccao = p_faccao;
	    
	    -- verificar remocao
	    IF SQL%ROWCOUNT = 0 THEN
	        raise e_faccao_nao_encontrada;
	    END IF;
	
	    COMMIT;
	  
	    dbms_output.put_line('Facção ' || p_faccao || ' removida da nação ' || p_nacao);
	
	EXCEPTION
	    WHEN e_faccao_nao_encontrada THEN
	        ROLLBACK;
	       	raise_application_error(-20001, 'Erro: Facção não encontrada para a nação informada.');
	    WHEN OTHERS THEN
	        ROLLBACK;
	       	raise_application_error(-20000, 'Erro ao remover facção: ' || SQLERRM);
	        raise;
	
	END remover_faccao;

END pacote_lider;





