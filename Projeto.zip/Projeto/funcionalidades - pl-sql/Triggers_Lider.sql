-- ========================= TRIGGER CREDENCIAMENTO DE COMUNIDADES =========================
--CREATE OR REPLACE TRIGGER trigger_view_gerenciamento_comunidades
--INSTEAD OF INSERT ON view_gerenciamento_comunidades
--FOR EACH ROW
--BEGIN
--    INSERT INTO participa(faccao, especie, comunidade)
--    VALUES (:NEW.faccao, :NEW.especie, :NEW.comunidade);
--END;

-- TRIGGER PARA VIEW NÃO MATERIALIZAVEL
CREATE OR REPLACE TRIGGER trigger_view_gerenciamento_comunidades
INSTEAD OF INSERT ON view_gerenciamento_comunidades
FOR EACH ROW
BEGIN

  INSERT INTO participa (faccao, especie, comunidade)
    VALUES (:NEW.faccao, :NEW.especie, :NEW.comunidade);
END;


--DROP TRIGGER trigger_view_gerenciamento_comunidades;
-- ========================= TRIGGER INSERT/UPDATE/DELETE FACCAO =========================
-- este trigger vincula a faccao à nacao do lider: nacao_faccao, o resto é automatico atravez da view de gerenciamento
CREATE OR REPLACE TRIGGER trigger_faccao
  	AFTER INSERT OR UPDATE OR DELETE ON faccao
  	FOR EACH ROW
  	
DECLARE
  	v_count NUMBER;
  	v_nacao nacao.nome%TYPE;
  
BEGIN

	SELECT l.nacao INTO v_nacao FROM lider l WHERE l.CPI = :NEW.lider;

	IF v_nacao IS NULL THEN
		raise no_data_found;
	END IF;
  
	IF INSERTING THEN
		SELECT COUNT(*) INTO v_count FROM nacao_faccao WHERE nacao = v_nacao AND faccao = :NEW.nome;
	  	IF v_count = 0 THEN
	  		INSERT INTO nacao_faccao(NACAO, FACCAO) VALUES(v_nacao, :NEW.nome);
		  	dbms_output.put_line('Nova facção inserida e vinculada à nação do líder!');
	   	END IF;
   	ELSIF UPDATING THEN
   	        SELECT COUNT(*) INTO v_count FROM nacao_faccao WHERE faccao = :OLD.nome;
        IF v_count > 0 THEN
            UPDATE nacao_faccao SET nacao = v_nacao WHERE faccao = :NEW.nome;
            dbms_output.put_line('Informações atualizadas!');
        ELSE
            INSERT INTO nacao_faccao (NACAO, FACCAO) VALUES (v_nacao, :NEW.nome);
            dbms_output.put_line('Nova facção inserida e vinculada à nação do líder!');
        END IF;
	ELSIF DELETING THEN
		SELECT COUNT(*) INTO v_count FROM nacao_faccao WHERE nacao = v_nacao AND faccao = :OLD.nome;
		IF v_count > 0 THEN
  			DELETE FROM nacao_faccao WHERE faccao = :OLD.nome;
  		END IF;
	END IF;
   
EXCEPTION
	WHEN no_data_found THEN
		raise_application_error(-20001, 'O líder informado não está cadastrado!');
		ROLLBACK;
END;

-- ========================= TRIGGER DELETE NACAO_FACCAO =========================
CREATE OR REPLACE TRIGGER trigger_nacao_faccao
    AFTER DELETE ON nacao_faccao
    FOR EACH ROW

DECLARE
    v_count NUMBER;
    v_especie comunidade.especie%TYPE;
    v_comunidade comunidade.nome%TYPE;

BEGIN
	-- verificando se tem registro em Participa
    SELECT COUNT(*) INTO v_count FROM PARTICIPA WHERE faccao = :OLD.faccao;

    IF v_count > 0 THEN
        -- obtendo especie e comunidade da tabela PARTICIPA
        SELECT p.especie, p.comunidade INTO v_especie, v_comunidade
        FROM PARTICIPA p WHERE faccao = :OLD.faccao
        AND ROWNUM = 1; -- adicionado ROWNUM = 1 para evitar mais de um resultado

        -- deletando da tabela PARTICIPA
        DELETE FROM PARTICIPA WHERE faccao = :OLD.faccao
        AND especie = v_especie AND comunidade = v_comunidade;
    ELSE
        raise_application_error(-20001, 'Facção não credenciada!');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        raise_application_error(-20001, 'Facção não credenciada!');
    WHEN OTHERS THEN
        raise_application_error(-20002, 'Erro: ' || SQLERRM);
END;


SELECT * FROM user_errors;



