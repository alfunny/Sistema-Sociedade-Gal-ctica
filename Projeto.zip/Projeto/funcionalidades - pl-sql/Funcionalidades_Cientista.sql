CREATE OR REPLACE PACKAGE pacote_cientista AS

    -- Variáveis para exceções personalizadas
    ex_estrela_nao_encontrada EXCEPTION;
    ex_estrela_ja_existente EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_estrela_nao_encontrada, -20001);
    PRAGMA EXCEPTION_INIT(ex_estrela_ja_existente, -20002);

    -- Procedure para criar uma nova estrela
    PROCEDURE criar_estrela(
        p_id_estrela estrela.ID_ESTRELA%TYPE,
        p_nome estrela.NOME%TYPE,
        p_classificacao estrela.CLASSIFICACAO%TYPE,
        p_massa estrela.MASSA%TYPE,
        p_x estrela.X%TYPE,
        p_y estrela.Y%TYPE,
        p_z estrela.Z%TYPE
    );

    -- Procedure para ler informações de uma estrela
    PROCEDURE ler_dados_estrela(p_id_estrela estrela.ID_ESTRELA%TYPE, v_cursor OUT SYS_REFCURSOR);

    -- Procedure para atualizar informações de uma estrela
    PROCEDURE atualizar_estrela(
        p_id_estrela estrela.ID_ESTRELA%TYPE,
        p_nome estrela.NOME%TYPE,
        p_classificacao estrela.CLASSIFICACAO%TYPE,
        p_massa estrela.MASSA%TYPE,
        p_x estrela.X%TYPE,
        p_y estrela.Y%TYPE,
        p_z estrela.Z%TYPE
    );

    -- Procedure para deletar uma estrela
    PROCEDURE deletar_estrela(p_id_estrela estrela.ID_ESTRELA%TYPE);

END pacote_cientista;

CREATE OR REPLACE PACKAGE BODY pacote_cientista AS

    --------------------- Definição criar_estrela ---------------------------
    PROCEDURE criar_estrela(
        p_id_estrela estrela.ID_ESTRELA%TYPE,
        p_nome estrela.NOME%TYPE,
        p_classificacao estrela.CLASSIFICACAO%TYPE,
        p_massa estrela.MASSA%TYPE,
        p_x estrela.X%TYPE,
        p_y estrela.Y%TYPE,
        p_z estrela.Z%TYPE
    ) IS
        v_count INTEGER;
    BEGIN
        -- Verificar se a estrela existe
        SELECT COUNT(*)
        INTO v_count
        FROM ESTRELA
        WHERE ID_ESTRELA = p_id_estrela;

        IF v_count > 0 THEN
            RAISE ex_estrela_ja_existente;
        END IF;

        -- Criar uma nova estrela
        INSERT INTO ESTRELA (ID_ESTRELA, NOME, CLASSIFICACAO, MASSA, X, Y, Z)
        VALUES (p_id_estrela, p_nome, p_classificacao, p_massa, p_x, p_y, p_z);

        DBMS_OUTPUT.PUT_LINE('Estrela criada com sucesso.');
    EXCEPTION
        WHEN ex_estrela_ja_existente THEN
            RAISE_APPLICATION_ERROR(-20002, 'Estrela já existe');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20000, 'Erro ao criar estrela: ' || SQLERRM);
    END criar_estrela;

    --------------------- Definição ler_dados_estrela ---------------------------
    PROCEDURE ler_dados_estrela(p_id_estrela estrela.ID_ESTRELA%TYPE, v_cursor OUT SYS_REFCURSOR) IS
        v_count INTEGER;
    BEGIN
        -- Verificar se a estrela existe
        SELECT COUNT(*)
        INTO v_count
        FROM ESTRELA
        WHERE ID_ESTRELA = p_id_estrela;

        IF v_count = 0 THEN
            RAISE ex_estrela_nao_encontrada;
        END IF;

        OPEN v_cursor FOR
            SELECT ID_ESTRELA, NOME, CLASSIFICACAO, MASSA, X, Y, Z FROM ESTRELA
            WHERE ID_ESTRELA = p_id_estrela;
    EXCEPTION
        WHEN ex_estrela_nao_encontrada THEN
            RAISE_APPLICATION_ERROR(-20001, 'Nenhuma estrela encontrada');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20000, 'Erro ao ler estrela: ' || SQLERRM);
    END ler_dados_estrela;

    --------------------- Definição atualizar_estrela ---------------------------
    PROCEDURE atualizar_estrela(
        p_id_estrela estrela.ID_ESTRELA%TYPE,
        p_nome estrela.NOME%TYPE,
        p_classificacao estrela.CLASSIFICACAO%TYPE,
        p_massa estrela.MASSA%TYPE,
        p_x estrela.X%TYPE,
        p_y estrela.Y%TYPE,
        p_z estrela.Z%TYPE
    ) IS
        v_count INTEGER;
    BEGIN
        -- Verificar se a estrela não existe
        SELECT COUNT(*)
        INTO v_count
        FROM ESTRELA
        WHERE ID_ESTRELA = p_id_estrela;

        IF v_count = 0 THEN
            RAISE ex_estrela_nao_encontrada;
        END IF;

        -- Atualizar informações de uma estrela
        UPDATE ESTRELA SET NOME = p_nome, CLASSIFICACAO = p_classificacao, 
        				   MASSA = p_massa, X = p_x, Y = p_y, Z = p_z
        				   WHERE ID_ESTRELA = p_id_estrela;

        DBMS_OUTPUT.PUT_LINE('Estrela atualizada com sucesso.');
    EXCEPTION
        WHEN ex_estrela_nao_encontrada THEN
            RAISE_APPLICATION_ERROR(-20001, 'Nenhuma estrela encontrada com esse ID');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20000, 'Erro ao atualizar estrela: ' || SQLERRM);
    END atualizar_estrela;

    --------------------- Definição deletar_estrela ---------------------------
    PROCEDURE deletar_estrela(p_id_estrela estrela.ID_ESTRELA%TYPE) IS
        v_count INTEGER;
    BEGIN
        -- Verificar se a estrela não existe
        SELECT COUNT(*)
        INTO v_count
        FROM ESTRELA
        WHERE ID_ESTRELA = p_id_estrela;

        IF v_count = 0 THEN
            RAISE ex_estrela_nao_encontrada;
        END IF;

        -- Deletar uma estrela
        DELETE FROM ESTRELA
        WHERE ID_ESTRELA = p_id_estrela;

        DBMS_OUTPUT.PUT_LINE('Estrela deletada com sucesso.');
    EXCEPTION
        WHEN ex_estrela_nao_encontrada THEN
            RAISE_APPLICATION_ERROR(-20001, 'Nenhuma estrela encontrada com esse ID');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20000, 'Erro ao deletar estrela: ' || SQLERRM);
    END deletar_estrela;

END pacote_cientista;
